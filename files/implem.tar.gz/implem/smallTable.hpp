#ifndef H_SMALLTABLE
#define H_SMALLTABLE

class smallTable{

	public:

		smallTable(){ m_Ti = new uint8_t[2097152];};

		~smallTable() {delete [] m_Ti;};

		uint8_t & operator()(unsigned int x, unsigned int y, unsigned int j){return m_Ti[8192*x + 32*y +j];};
		uint8_t const & operator()(unsigned int x, unsigned int y, unsigned int j) const {return m_Ti[8192*x + 32*y +j];};

		uint8_t * operator()(unsigned int x){return m_Ti + 8192*x;};
		uint8_t const * operator()(unsigned int x) const {return m_Ti + 8192*x;};

		uint8_t * operator()(unsigned int x, unsigned int y){return m_Ti + 8192*x + 32*y;};
		uint8_t const * operator()(unsigned int x, unsigned int y)const {return m_Ti + 8192*x + 32*y;};


	private:

		uint8_t * m_Ti;
};


#endif