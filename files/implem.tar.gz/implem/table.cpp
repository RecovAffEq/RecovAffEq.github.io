#include "table.hpp"

using namespace std;
using namespace NTL;

void generateTable(std::string filename, unsigned int rMax, vector<uint8_t> key){
	//Generate the table for Rmax rounds of masked AES using key in filename
	//Expected time is roughly 30min for a 10 rounds AES
	//Will also generate a file secret_encodings.txt containing the first encoding A0 and the output external encoding M_out
	//in a format such that one can easoly checkk if the attack recovers the correct encodings
	//The input external encoding M_in is not used in the attack and would only be given in a matrix format
	//so it's not generated, and the attack will output A0 which is sufficient to recover M_in if provided afterward

	cout << "Generating tables, expected time for 10 round AES : ~30min..." << endl;
	//AES key expand
	auto roundKey = KeyExpansion(key,rMax);
	//round keys are stored in a 4x4 array, store them in "rows" for conveniency
	vector<vector<uint8_t>> RK(rMax+1,vector<uint8_t>(16));
	for(unsigned int r = 0; r <= rMax; r++){
		for(unsigned int j = 0; j < 4; j++){
			for(unsigned int i = 0; i < 4; i++){
				RK[r][j*4+i] = roundKey[r][i][j];
			}
		}
	}

	vector<vector<vector<mat_GF2>>> A(rMax); //A[r] will contains the non zero blocks of Ar as { ..., {Ar_i,i , Ar_i,i+1}, ... }
	vector<vector<mat_GF2>> a(rMax); //a[r] will contains the 32 8bit blocks ar_i
	vector<vector<mat_GF2>> B(rMax); //B[r] will contains the blocks of Br as {Br_1,..., Br_32}
	vector<vector<mat_GF2>> b(rMax); //b[r] will contains the br_i
	vector<vector<vector<mat_GF2>>> h(rMax, vector<vector<mat_GF2>>(32, vector<mat_GF2>(256))); //h[r][i][x] contains hr_i(x) as a 256x1 vector

	//Build the diffusion and SR matrix for 2 parallel AES
	mat_GF2 diff(AES_diffusion_matrix_GF2());
	mat_GF2 SR(AES_SR_matrix_GF2());

	{mat_GF2 nullMatdiff, nullMatSR;
	nullMatdiff.SetDims(128,128);
	nullMatSR.SetDims(128,128);
	ref_mat_augment(diff, nullMatdiff); // diff = M | 0
	ref_mat_augment(SR, nullMatSR);		//SR = SR | 0
	ref_mat_augment(nullMatdiff, AES_diffusion_matrix_GF2()); //nullMatdiff = 0 | M
	ref_mat_augment(nullMatSR, AES_SR_matrix_GF2()); //nullMatSR = 0 | SR
	ref_mat_stack(diff, nullMatdiff);
	ref_mat_stack(SR, nullMatSR);}

	ofstream secretFileEncodings("secret_encodings.txt", ios::out | ios::trunc); //will contains A0 and Mout
	for(unsigned int r = 0; r <= rMax; r++){
		//Generate the vectors of ar
		vector<mat_GF2> aVec(32);
		for(unsigned int i  = 0; i < 32; i++){
			aVec[i] = random_mat_GF2(8,1);
		}

		//Generate the block of Ar until Ar is invertible
		while(1){
			vector<vector<mat_GF2>> ArBlock(32, vector<mat_GF2>(2));

			for(unsigned int i = 0; i < 32; i++){
				ArBlock[i][0] = random_mat_GF2(8,8);
				ArBlock[i][1] = random_mat_GF2(8,8);
			}

			//Build Ar by concatenating blocks
			mat_GF2 Ar;
			Ar.SetDims(0,256);
			//build all block from 0 to 30, the block 31 will be built separately
			for(unsigned int i = 0; i < 31; i++){
				mat_GF2 row;
				//begin with i 8x8 null matrix before the block Ar_i,i | Ar_i,i+1
				row.SetDims(8,i*8);
				//now the two blocks
				ref_mat_augment(row, ArBlock[i][0]);
				ref_mat_augment(row, ArBlock[i][1]);
				//Complete with 8x8 null matrix
				mat_GF2 nullMat;
				nullMat.SetDims(8,(32-(i+2))*8);
				ref_mat_augment(row, nullMat);

				ref_mat_stack(Ar, row);
			}

			//build the last row block
			{mat_GF2 row(ArBlock[31][1]);
			mat_GF2 nullMat;
			nullMat.SetDims(8,256-16);
			ref_mat_augment(row, nullMat);
			ref_mat_augment(row, ArBlock[31][0]);
			ref_mat_stack(Ar, row);}

			if(determinant(Ar) == 1){
				//Ar is invertible
				if(r == 0){
					//Build ar by stacking its pieces
					mat_GF2 ar;
					ar.SetDims(0,1);
					for(unsigned int i = 0; i < 32; i++){
						ref_mat_stack(ar, aVec[i]);
					}
					//save A0 in encodings.txt
					secretFileEncodings << "A0 : " << endl;
					superCompactPrint(Ar, secretFileEncodings);
					secretFileEncodings << "a0 : " << endl;
					superCompactPrint(transpose(ar), secretFileEncodings);
				}
				if(r > 0){
					if(r < rMax){
						//dont need inv(A0)
						//compute B(r-1) = Ar^(-1)
						mat_GF2 invAr(inv(Ar));
						mat_GF2 Br(invAr*diff);

						//split Br into 32 blocks of size 256 x 8
						vector<mat_GF2> BrBlock(32);
						for(unsigned int t = 0; t < 32; t++){
							//for the t-th block
							mat_GF2 block;
							block.SetDims(256,8);
							for(unsigned int i = 0; i < 256; i++){
								auto & rowBlock = block[i];
								auto & rowBr = Br[i];
								for(unsigned int j = 0; j < 8; j++){
									rowBlock[j] = rowBr[8*t+j];
								}
							}
							BrBlock[t] = move(block);
						}

						//compute br
						//first concatenate the blocks ar_i to build ar
						mat_GF2 ar;
						ar.SetDims(0,1);
						for(unsigned int i = 0; i < 32; i++){
							ref_mat_stack(ar, aVec[i]);
						}
						
						mat_GF2 br(invAr*ar);
						//generate the br_i
						vector<mat_GF2> brVec(32);
						brVec[31] = br;
						//the first 31 br_i are random
						//br_31 = br + br_0 + ... + br_30
						for(unsigned int i = 0; i < 31; i++){
							brVec[i] = random_mat_GF2(256,1);

							brVec[31] += brVec[i];
						}

						//store the block of Br and the br_i
						B[r-1] = move(BrBlock);
						b[r-1] = move(brVec);
					}
					else{
						//the last Br is only Mout*(SR+RK[rmax])
						mat_GF2 Mout = random_invertible_mat_GF2(256);
						secretFileEncodings << "Mout : " << endl;
						superCompactPrint(Mout,secretFileEncodings);

						mat_GF2 Br(Mout*SR);
						//split Br into 32 blocks of size 256 x 8
						vector<mat_GF2> BrBlock(32);
						for(unsigned int t = 0; t < 32; t++){
							//for the t-th block
							mat_GF2 block;
							block.SetDims(256,8);
							for(unsigned int i = 0; i < 256; i++){
								auto & rowBlock = block[i];
								auto & rowBr = Br[i];
								for(unsigned int j = 0; j < 8; j++){
									rowBlock[j] = rowBr[8*t+j];
								}
							}
							BrBlock[t] = move(block);
						}
						mat_GF2 br;
						br.SetDims(256,1); //the last br is Mout*RK[rmax] + random_column
						for(unsigned int wbr = 0; wbr < 32; wbr++){
							uint8_t RKw = RK[rMax][wbr%16];
							for(unsigned int w = 0; w < 8; w++){
								br[8*wbr+w][0] = (RKw >> w)&1;
							}
						}
						br = Mout*br;
						mat_GF2 mout = random_mat_GF2(256,1);
						secretFileEncodings << "mout : " << endl;
						superCompactPrint(transpose(mout),secretFileEncodings);
						br += mout;
						
						//generate the br_i
						vector<mat_GF2> brVec(32);
						brVec[31] = br;
						//the first 31 br_i are random
						//br_31 = br + br_0 + ... + br_30
						for(unsigned int i = 0; i < 31; i++){
							brVec[i] = random_mat_GF2(256,1);

							brVec[31] += brVec[i];
						}
						//store the block of Br and the br_i
						B[r-1] = move(BrBlock);
						b[r-1] = move(brVec);
					}

				}
				if(r < rMax){
					//dont need to store the last affine transformation

					//store Ar (as blocks) and ar (as blocks)
					A[r] = move(ArBlock);
					a[r] = move(aVec);

					//build hr
					for(unsigned int i = 0; i < 32; i++){
						for(unsigned int x = 0; x < 256; x++){
							h[r][i][x] = random_mat_GF2(256,1);
						}
					}
				}

				break;
			}
		}
	}
	cout << "Matrix generation ok" << endl;

	//time to generated the tables...
	ofstream outfile(filename, ios::out | ios::trunc | ios::binary);
	for(unsigned int r = 0; r < rMax; r++){ 
		for(unsigned int i = 0; i < 32; i++){
			for(unsigned int x = 0; x < 256; x++){
				for(unsigned int y = 0; y < 256; y++){
					mat_GF2 vx(matGF2FromUint8(x));
					mat_GF2 vy(matGF2FromUint8(y));

					//compute z = SBOX((Ai,i Ai,i+1).(x,y) + ai + RKi)
					mat_GF2 tmp(A[r][i][0]*vx + A[r][i][1]*vy + a[r][i] + matGF2FromUint8(RK[r][i%16]));
					uint8_t z = getSbox(uint8FromMatGF2(tmp));
					mat_GF2 vz(matGF2FromUint8(z));

					//t = Bi.z + bi + hi(x) + hi+1(y)
					mat_GF2 vt(B[r][i]*vz + b[r][i] + h[r][i][x] + h[r][(i+1)%32][y]);

					//at this point vt is a 256x1 matrix, which we will cut in 32 * uint8_t
					for(unsigned int j = 0; j < 32; j++){
						mat_GF2 vtBlock;
						vtBlock.SetDims(8,1);
						for(unsigned int s = 0; s < 8; s++){
							vtBlock[s][0] = vt[8*j + s][0];
						}
						
						uint8_t val = uint8FromMatGF2(vtBlock);
						outfile.write((char*)&val, sizeof(uint8_t));
						
					}
				}
			}
		}
	}
	


}