#ifndef H_SEEKANDDESTROY
#define H_SEEKANDDESTROY


#include "Attack.hpp"
#include "AES.hpp"
#include "WBscheme.hpp"
#include <ctime>
#include <random>
#include <iostream>

std::tuple<std::vector<uint8_t>, NTL::mat_GF2, NTL::mat_GF2, NTL::mat_GF2, NTL::mat_GF2> breakWhiteBoxAgain(std::string inTable, std::string outEncodings);
//input :
//	- intTable : file containing the WB table
//	- outEncodings : file where the encodings Mout and A0 will be printed for checking
// return a tuple {key, Mout, mout, A0, a0}

std::tuple<NTL::mat_GF2, NTL::mat_GF2, NTL::mat_GF2, NTL::mat_GF2> breakOneRound(RoundFunction const & Tr);
//Return an equivalent representation of the round given as {M,m,B.A',b}

#endif