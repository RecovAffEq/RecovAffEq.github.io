#include "breakWB.hpp"

using namespace std;
using namespace NTL;

tuple<vector<uint8_t>, mat_GF2, mat_GF2, mat_GF2, mat_GF2> breakWhiteBoxAgain(std::string inTable, std::string outEncodings){
	//input :
	//	- intTable : file containing the WB table
	//	- outEncodings : file where the encodings Mout and A0 will be printed for checking
	// return a tuple {key, Mout, mout, A0, a0}



	clock_t start, glob_start;
	double duration;
	glob_start = clock();
	start = clock();

	auto const sboxAES = AES_SBOX();

    auto listEquiv = selfEquivAES();
    // unsigned int nbSelfEquiv = listEquiv.size();
	//listEquiv contains all {A1,A2,a2} such that S(x) = A2(S(A1(x)))+a2 i.e. S = A2 o S o A1

	vector<vector<uint8_t>> tableMultiply(256, vector<uint8_t>(256));
	for(unsigned int x = 0; x < 256; x++){
		for(unsigned int y = 0; y < 256; y++){
			tableMultiply[x][y] = multiplyGF256(x,y);
		}
	}

	//////////////////////////////////////////////////////
	//Compute the lin. equiv. classes of the AES Sbox
	//////////////////////////////////////////////////////

	cout << "Computing the lin. equiv. classes of the AES Sbox..." << flush;
	start = clock();
	//since the AES sbox doesn't change, we can compute all of the lin. equiv. class of S1(x+a) once
	auto linEqClass = equivClassAES();
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;


	//////////////////////////////////////////////////////
	//Read the table
	//////////////////////////////////////////////////////
	start = clock();
	unsigned int rMax = 10;
	cout << "Reading table..." << flush;
	WBscheme T(inTable, rMax);

	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;



	//////////////////////////////////////////////////////
	//Matrix of(MCSR,MCSR)
	//////////////////////////////////////////////////////
	//Build the diffusion and SR matrix for 2 parallel AES
	mat_GF2 MCSR(AES_diffusion_matrix_GF2());

	{mat_GF2 nullMatdiff;
	nullMatdiff.SetDims(128,128);
	ref_mat_augment(MCSR, nullMatdiff); // MCSR = M | 0
	ref_mat_augment(nullMatdiff, AES_diffusion_matrix_GF2()); //nullMatdiff = 0 | M
	ref_mat_stack(MCSR, nullMatdiff);}


	//////////////////////////////////////////////////////
	//Compute all A'r
	//////////////////////////////////////////////////////
	cout << "Computing A'0 and A'1..." << flush;
	start = clock();
	vector<mat_GF2> listAprime(2);
	for(unsigned int r = 0; r < 2; r++){
		listAprime[r] = computeAprime(T(r));
	}
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;


	//////////////////////////////////////////////////////
	//Compute all the inverse of A'r
	//////////////////////////////////////////////////////
	cout << "Computing inv(A'0) and inv(A'1)..." << flush;
	start = clock();
	vector<mat_GF2> listInvAprime(2);
	for(unsigned int r = 0; r < 2; r++){
		listInvAprime[r] = inv(listAprime[r]);
	}
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;



	//////////////////////////////////////////////////////
	//Compute candidates for B1,...,B32 on the last round
	//////////////////////////////////////////////////////
	cout << "Computing candidates for B0,...,B31..." << endl;
	start = clock();
	auto listCandidateBi = computeCandidates(T(1), listInvAprime[1],linEqClass,listEquiv);
	// listCandidateBi[i] contains all 2040 candidates {Bi,bi}
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << "Total time for candidates for B0,...,B31 : " << duration << "s" << endl;



    //////////////////////////////////////////////////////
	//Compute a candidate for each Ci
	//////////////////////////////////////////////////////
	cout << "Computing candidates for C0,...,C31..." << endl;
	start = clock();
	auto listCandidateCi = computeCandidates(T(0), listInvAprime[0], linEqClass, listEquiv);
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << "Total time for candidates for C0,...,C31 : " << duration << "s" << endl;

	
	//////////////////////////////////////////////////////
	//Do the MITM to match the good candidates
	//////////////////////////////////////////////////////
	// (B0 B1 B2 B3 C0 C5 C10 C15)
	vector<pair<mat_GF2,mat_GF2>> foundBlockB(32);
	vector<pair<mat_GF2,mat_GF2>> foundBlockC(32);
	for(unsigned int numBlock = 0; numBlock < 8; numBlock++){
		cout << "Search block " << numBlock << "..." << flush;
		start = clock();
		auto goodBlock = searchBlock(T(0),listAprime[1],listInvAprime[0],listCandidateBi,listCandidateCi,numBlock);
		duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
		cout << "Time for block " << numBlock << " " << duration << "s" << endl;

		vector<uint8_t> iblockB(4);
		vector<uint8_t> iblockC(4);
		for(unsigned int i = 0; i < 4; i++){
			iblockB[i] = 4*numBlock+i;

			iblockC[i] = (4*numBlock + (5*i))%16 + 16*(numBlock/4);
		}

		for(unsigned int i = 0; i < 4; i++){
			foundBlockB[iblockB[i]] = move(goodBlock[i]);
			foundBlockC[iblockC[i]] = move(goodBlock[i+4]);
		}
	}


	//////////////////////////////////////////////////////
	//Build B and C
	//////////////////////////////////////////////////////
	cout << "Building B and C..." << flush;
	start = clock();
	mat_GF2 foundB; foundB.SetDims(0,256);
	mat_GF2 foundb; foundb.SetDims(0,1);
	mat_GF2 foundC; foundC.SetDims(0,256);
	mat_GF2 foundc; foundc.SetDims(0,1);
	for(unsigned int i = 0; i < 32; i++){
		mat_GF2 rowB; rowB.SetDims(8,8*i);
		mat_GF2 rowC; rowC.SetDims(8,8*i);
		mat_GF2 nullMat; nullMat.SetDims(8,256-8*(i+1));

		ref_mat_augment(rowB, foundBlockB[i].first);
		ref_mat_augment(rowC, foundBlockC[i].first);
		ref_mat_augment(rowB, nullMat);
		ref_mat_augment(rowC, nullMat);

		ref_mat_stack(foundB, rowB);
		ref_mat_stack(foundC, rowC);
		ref_mat_stack(foundb, foundBlockB[i].second);
		ref_mat_stack(foundc, foundBlockC[i].second);

	}

	mat_GF2 foundA0 = foundC*listAprime[0];
	mat_GF2 foundinvA0 = inv(foundA0);
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;


	//////////////////////////////////////////////////////
	//Recover the master key
	//////////////////////////////////////////////////////
	cout << "Recovering the master key..." << flush;
	start = clock();
	//We get B + (b+k) and want to extract the key
	//so first compute z = (MCSR o (S...S) o (C + (c+k)) + Ar') (x)
	//We can take x = 0 for easier computation
	//C o Ar'(0) = C.Ar'.0 + c = c
	//We already have the 32x8bits blocks of c ( c0 ... c32) as foundBlockC[i].second
	//So compute S(c)
	mat_GF2 Sc; Sc.SetDims(0,1);
	for(unsigned int i = 0; i < 32; i++){
		mat_GF2 Sci = matGF2FromUint8(sboxAES[uint8FromMatGF2(foundBlockC[i].second)]);
		ref_mat_stack(Sc, Sci);
	}
	//z = MCSR(S(c))
	mat_GF2 z = MCSR*Sc;

	//Then compute y = SumTj(x)
	vector<uint8_t> x(32,0);
	mat_GF2 y = mat_SumTjx(T(0), x);

	//The we know that y = invA'_{r+1} * (invB*z + invb) where invb = invB*b
	//So invb = A'_{r+1}*y + invB*z
	//and finally b = B*A'_{r+1}*y + z;
	mat_GF2 matb = foundB*listAprime[1]*y + z;

	//And then RK[r+1] = foundb + matb
	mat_GF2 matRKrp1 = foundb + matb;
	vector<uint8_t> foundKey(16);
	for(unsigned int i = 0; i < 16; i++){
		uint8_t rki = 0;
		for(unsigned int b = 0; b < 8; b++){
			if(matRKrp1[8*i+b][0] == 1){
				rki ^= (1<<b);
			}
		}
		foundKey[i] = move(rki);
	}
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;

	auto masterKey = invFirstRoundKeySchedule(foundKey);
	cout << "Master key found : ";
	for(unsigned int i = 0; i < 16; i++){
		printf("%02x", masterKey[i]);
	}
	cout << endl;

	//foundc is key ^ a0, so extract a0
	//first the vector representing the key
	mat_GF2 matMK; matMK.SetDims(0,1);
	for(unsigned int i = 0; i < 32; i++){
		ref_mat_stack(matMK, matGF2FromUint8(masterKey[i%16]));
	}
	mat_GF2 founda0(foundc + matMK);
	mat_GF2 foundinva0(foundinvA0*founda0);



	//////////////////////////////////////////////////////
	//Recover the output encoding Mout
	//////////////////////////////////////////////////////
	cout << "Recovering the output encoding Mout..." << flush;
	start = clock();
	auto foundRoundKey = KeyExpansion(masterKey, 10);

	//Compute the decryption of each vector (0,...,1,...,0) and (0...0)
	//store it as a 128x1 mat_gf2
	vector<mat_GF2> vecXt(129);
	for(unsigned int i = 0; i < 129; i++){
		vector<uint8_t> y(16,0);
		//i = 0 => decrypt (0...0)
		//else decrypt (0,...,1,...,0)
		if(i != 0){
			y[(i-1)/8] = (1 << ((i-1)%8));
		}

		vector<uint8_t> xt = invAES(y, foundRoundKey);
		mat_GF2 matxt; matxt.SetDims(0,1);
		for(unsigned int b = 0; b < 16; b++){
			ref_mat_stack(matxt, matGF2FromUint8(xt[b]));
		}

		vecXt[i] = move(matxt);
	}


	//Get the translation vector of Mout using the decryption of (0...00...0)
	mat_GF2 matxt0(vecXt[0]);
	ref_mat_stack(matxt0, vecXt[0]);
	mat_GF2 matx0(foundinvA0*matxt0 + foundinva0);
	//get the corresponding 32x8 bits vector
	vector<uint8_t> x0(32);
	for(unsigned int i = 0; i < 32; i++){
		uint8_t xi = 0;
		for(unsigned int b = 0; b < 8; b++){
			if(matx0[8*i+b][0] == 1){
				xi ^= (1<<b);
			}
		}
		x0[i] = move(xi);
	}

	//get z = (Mout o (AES,AES) o A0)(x) using the tables
	vector<uint8_t> z0 = T.encrypt(x0);

	//Then z = Mout.y + mout, since y =0, z = mout
	//Get the mat_gf2 vector
	mat_GF2 mout; mout.SetDims(0,1);
	for(unsigned int i = 0; i < 32; i++){
		ref_mat_stack(mout, matGF2FromUint8(z0[i]));
	}

	//Now get the column of Mout as image of (0,...,1,...,0)
	mat_GF2 Mout; Mout.SetDims(256,0);
	for(unsigned int j = 1; j <= 256; j++){
		mat_GF2 matx;
		if(j <= 128){
			//first from y = (0...1...0 0...0)
			mat_GF2 matxt(vecXt[j]);
			ref_mat_stack(matxt, vecXt[0]);
			matx = foundinvA0*matxt + foundinva0;
		}
		else{
			//then from y = (0...0 0...1...0)
			mat_GF2 matxt(vecXt[0]);
			ref_mat_stack(matxt, vecXt[j-128]);
			matx = foundinvA0*matxt + foundinva0;
		}

		//get the corresponding 32x8 bits vector
		vector<uint8_t> x(32);
		for(unsigned int i = 0; i < 32; i++){
			uint8_t xi = 0;
			for(unsigned int b = 0; b < 8; b++){
				if(matx[8*i+b][0] == 1){
					xi ^= (1<<b);
				}
			}
			x[i] = move(xi);
		}
		//get z = (Mout o (AES,AES) o A0)(x) using the tables
		vector<uint8_t> z = T.encrypt(x);
		//Get the mat_gf2 vector
		mat_GF2 col; col.SetDims(0,1);
		for(unsigned int i = 0; i < 32; i++){
			ref_mat_stack(col, matGF2FromUint8(z[i]));
		}

		//concatenate to Mout
		ref_mat_augment(Mout, col+mout);
	}
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;

	cout << "Found encodings in " << outEncodings << endl;

	ofstream fileEncodings(outEncodings, ios::out | ios::trunc);

	fileEncodings << "A0 : " << endl;
	superCompactPrint(foundA0, fileEncodings);
	fileEncodings << "a0 : " << endl;
	superCompactPrint(transpose(founda0), fileEncodings);
	fileEncodings << "Mout : " << endl;
	superCompactPrint(Mout,fileEncodings);
	fileEncodings << "mout : " << endl;
	superCompactPrint(transpose(mout),fileEncodings);



	duration = (clock() - glob_start)/ (double) CLOCKS_PER_SEC;
	cout << "global time : " << duration << endl;

	return make_tuple(masterKey, Mout, mout, foundA0, founda0);
}

tuple<mat_GF2, mat_GF2, mat_GF2, mat_GF2> breakOneRound(RoundFunction const & Tr){
	//Return an equivalent representation of the round given as {M,m,B.A',b}

	clock_t start, glob_start;
	double duration;
	glob_start = clock();
	start = clock();

	auto const sboxAES = AES_SBOX();
	//////////////////////////////////////////////////////
	//Matrix of(MCSR,MCSR)
	//////////////////////////////////////////////////////
	//Build the diffusion and SR matrix for 2 parallel AES
	mat_GF2 MCSR(AES_diffusion_matrix_GF2());

	{mat_GF2 nullMatdiff;
	nullMatdiff.SetDims(128,128);
	ref_mat_augment(MCSR, nullMatdiff); // MCSR = M | 0
	ref_mat_augment(nullMatdiff, AES_diffusion_matrix_GF2()); //nullMatdiff = 0 | M
	ref_mat_stack(MCSR, nullMatdiff);}


	//////////////////////////////////////////////////////
	//Compute the lin. equiv. classes of the AES Sbox
	//////////////////////////////////////////////////////
	cout << "Computing the lin. equiv. classes of the AES Sbox..." << flush;
	start = clock();
	//since the AES sbox doesn't change, we can compute all of the lin. equiv. class of S1(x+a) once
	auto linEqClass = equivClassAES();
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;


	//////////////////////////////////////////////////////
	//Compute A' and its inverse
	//////////////////////////////////////////////////////
	cout << "Computing A' and its inverse..." << flush;
	start = clock();
	mat_GF2 Aprime = computeAprime(Tr);
	mat_GF2 invAprime = inv(Aprime);
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " " << duration << "s" << endl;


	//////////////////////////////////////////////////////
	//Compute one candidate for each Bi
	//////////////////////////////////////////////////////
	cout << "Computing one candidate for each Bi..." << endl;
	start = clock();
	auto oneCandidateBi = computeOneCandidate(Tr, invAprime, linEqClass);
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << "Total time for one candidate for each Bi : " << duration << "s" << endl;

	//////////////////////////////////////////////////////
	//Build the corresponding equivalent M
	//////////////////////////////////////////////////////
	cout << "Building M..." << endl;
	start = clock();
	auto M = buildEquivM(Tr, invAprime, oneCandidateBi);
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << "Total time for building M : " << duration << "s" << endl;

	//////////////////////////////////////////////////////
	//Retrieve the corresponding translation m
	//////////////////////////////////////////////////////
	//First build B
	mat_GF2 B; B.SetDims(0,256);
	mat_GF2 b; b.SetDims(0,1);
	for(unsigned int i = 0; i < 32; i++){
		//Each row block of B is 	0|...| Bi |...|0
		mat_GF2 rowblock; rowblock.SetDims(8, 8*i);
		ref_mat_augment(rowblock, oneCandidateBi[i].first);
		mat_GF2 nullmat; nullmat.SetDims(8,256 - 8*(i+1));
		ref_mat_augment(rowblock, nullmat);

		ref_mat_stack(B, rowblock);
		ref_mat_stack(b, oneCandidateBi[i].second);
	}

	//Compute y = M*S(B(A'(x)))) and z = sumTj(x)
	//Then m = y+z
	//The value of x doesn't matter, so take x = 0
	//This lead to y = M.S(B.A'.0 + b) = M.S(b)

	//first compute w = S(b) = S(b0)...S(b31)
	mat_GF2 w; w.SetDims(0,1);
	for(unsigned int i = 0; i < 32; i++){
		ref_mat_stack(w, matGF2FromUint8(getSbox(uint8FromMatGF2(oneCandidateBi[i].second))));
	}
	// y = M*w;

	//Then z = sumTj (0...0);
	vector<uint8_t> x(32,0);
	mat_GF2 m = M*w + mat_SumTjx(Tr, x);

	duration = (clock() - glob_start)/ (double) CLOCKS_PER_SEC;
	cout << "global time : " << duration << endl;


	return make_tuple(M,m,B*Aprime,b);

}