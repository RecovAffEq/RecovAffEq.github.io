#include <ctime>
#include <random>
#include <iostream>
#include <fstream>


using namespace std;

static const uint8_t ASCIIHexToInt[] =
{
    // ASCII
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
     0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 255, 255, 255, 255, 255, 255,
    255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,

    // 0x80-FF (Omit this if you don't need to check for non-ASCII)
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
};

int main(int argc, char *argv[])
{	
	if(argc != 2){
		cout << "Error on input, should be called with ./encryptWB m, where m is an hexadecimal 32 bytes block" << endl;
		return 1;
	}

	//init message
	vector<uint8_t> m(32,0);
	for(uint8_t i = 0; i < 32; i++){
		auto & mi = m[i];
		uint8_t hexToInt_i = ASCIIHexToInt[argv[1][63-(2*i)]];
		uint8_t hexToInt_ip1 = ASCIIHexToInt[argv[1][63-(2*i+1)]];

		mi |= hexToInt_i;
		mi |= ( hexToInt_ip1 << 4);
	}
	// cout << "Message : ";
	// for(int i = 31; i >= 0; i--){
	// 	printf("%02x", m[i]);
	// }
	// cout << endl;

	//init tab
	uint8_t * T = new uint8_t[10*32*256*256*32];

	ifstream infile("AESTable.tab", ios::in | ios::binary);
	if(!infile.is_open())
    {
        cout << "Failed to open file!\n";
        exit(EXIT_FAILURE);
    }

    infile.read((char*) T, 10*32*256*256*32*sizeof(uint8_t));

	vector<uint8_t> c(m);
	for(unsigned int r = 0;  r < 10; r++){
		vector<uint8_t> tmp(32,0);	//tmp = Fr(x)
		uint64_t offR = 67108864*r;
		for(unsigned int i = 0; i < 32; i++){
			uint64_t offI = 2097152*i;
			uint64_t offCI = 8192*c[i];
			uint64_t offCIP1 = 32*c[(i+1)%32];
			for(unsigned int j = 0; j < 32; j++){
				//tmp[j] ^= T[r][i][c[i]][c[(i+1)%32]][j];	//sum_i(T[r][i])
				tmp[j] ^= T[offR + offI + offCI + offCIP1 + j];
			}
		}
		c = move(tmp);
	}

	for(int i = 31; i >= 0; i--){
		printf("%02x", c[i]);
	}
	
}