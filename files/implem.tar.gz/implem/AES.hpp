#ifndef H_AES
#define H_AES

#include <NTL/mat_GF2.h>
#include <vector>
#include <map>
#include <cstdint>
#include "GF2E_function.hpp"

uint8_t getSbox(uint8_t x); 	//get Sbox(x)
uint8_t getInvSbox(uint8_t x); 	//get invSbox(x)

std::vector<std::vector<std::vector<uint8_t>>> KeyExpansion(std::vector<uint8_t> key, unsigned int R);
//Expand key on R round using the AES key schedule
//Return a vector of the R+1 round keys

uint8_t MC_intCoeff(unsigned int i, unsigned int j);
//return the (i,j) coefficient of the matrix of MixColumns as integer

NTL::mat_GF2E matrix_SR();				//return the 16x16 matrix of the ShiftRows operation in GF2E
NTL::mat_GF2 AES_SR_matrix_GF2();		//return the 128x128 matix of SR operation in GF2
 
NTL::mat_GF2E AES_diffusion_matrix();	//return the 16x16 matrix of the linear layer of AES (MC o SR) in GF2E	
NTL::mat_GF2 AES_diffusion_matrix_GF2();//return the 128x128 matrix of the linear layer of AES (MC o SR) in GF2

std::pair<NTL::mat_GF2,NTL::mat_GF2> AES_SBOX_Aff();
//return the affine mapping used to build the AES Sbox as a pair of GF2 matrices {direction,translation}

std::vector<NTL::mat_GF2> listMultGF2();
//return a vector M such that M[a] contains the 8x8 matrix corresponding to the multiplication by a in GF2^8

NTL::mat_GF2 GF256_squaringMatrix();
//return the matrix corresponding to the squaring operation in the Rinjdael Field

std::vector<uint8_t> AES_SBOX();	//return a vector containg the AES sbox
std::vector<uint8_t> AES_invSBOX();	//return a vector containing the inverse of the AES sbox

NTL::GF2X AES_modulus();
//return the modulus used to build the Rinjdael field


uint8_t xtime(uint8_t x);
//return the result of a*x in the Rinjdael field as a uint8 where a is a generator of the field
uint8_t multiplyGF256(uint8_t x, uint8_t y);
//return x*y as a uint8 in the Rinjdael field
std::vector<std::vector<uint8_t>> GF256TableMultiply();
//return the tables of all possible mutliplication in the Rinjdael Field


//operation used to compute the inverse of AES
void AddRoundKey(std::vector<std::vector<uint8_t>> & state, std::vector<std::vector<uint8_t>> const & roundKey);
void InvSubBytes(std::vector<std::vector<uint8_t>> & state);
void InvShiftRows(std::vector<std::vector<uint8_t>> & state);
void InvMixColumns(std::vector<std::vector<uint8_t>> & state);
std::vector<uint8_t> invAES(std::vector<uint8_t> const & cipher, std::vector<std::vector<std::vector<uint8_t>>> const & roundKey);

//inverse the first roudn of the key schedule
std::vector<uint8_t> invFirstRoundKeySchedule(std::vector<uint8_t> const & RK);

#endif