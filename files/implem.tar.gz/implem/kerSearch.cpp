#include "kerSearch.hpp"

using namespace std;
using namespace NTL;

void filterkerL1(smallTable const & Tri, std::set<uint8_t> & K1, const uint8_t a, const uint8_t b){
	//We want to keep elements x of K1 such that 
	// f : y -> T(a+x,b+y) + T(a,b+y) is constant
	auto it_x = K1.begin();
	auto K1_end = K1.end();
	while(it_x != K1_end){
		uint8_t x = *it_x;

		//init fy with y=0
		uint8_t fy0[32];
		for(unsigned int j = 0; j < 32; j++){
			//fy0 = f(0) = T(a+x,b) + T(a,b)
			fy0[j] = Tri(a^x,b,j) ^ Tri(a,b,j);
		}

		bool isconst = true;
		for(unsigned int y = 1; y < 256; y++){
			//compute f(y) = T(a+x,b+y) + T(a,b+y)
			for(unsigned int j = 0; j < 32; j++){
				uint8_t fyj = Tri(a^x,b^y,j) ^ Tri(a,b^y,j);
				if(fyj != fy0[j]){
					isconst = false;
					break;
				}
			}
			if(!isconst){
				break;
			}
		}
		if(!isconst){
			it_x = K1.erase(it_x);
		}
		else{
			it_x++;
		}
	}
}

void filterkerL2(smallTable const & Tri, std::set<uint8_t> & K2, const uint8_t a, const uint8_t b){
	//We want to keep elements y in K2 such that
	// f : x -> T(a+x,b+y) + T(a+x,b) is constant
	auto it_y = K2.begin();
	auto K2_end = K2.end();
	while(it_y != K2_end){
		uint8_t y = *it_y;

		//init fx with x = 0
		uint8_t fx0[32];
		for(unsigned int j = 0; j < 32; j++){
			//f(0) = T(a,b+y) + T(a,b)
			fx0[j] = Tri(a,b^y,j) ^ Tri(a,b,j);
		}

		bool isconst = true;
		for(unsigned int x = 1; x < 256; x++){
			//compute f(x) = T(a+x,b+y) + T(a+x,b)
			for(unsigned int j = 0; j < 32; j++){
				uint32_t fxj = Tri(a^x,b^y,j) ^ Tri(a^x,b,j);
				if(fxj != fx0[j]){
					isconst = false;
					break;
				}
			}
			if(!isconst){
				break;
			}
		}
		if(!isconst){
			it_y = K2.erase(it_y);
		}
		else{
			it_y++;
		}
	}
}

void filter(smallTable const & Tri, std::set<pair<uint8_t, uint8_t>> & S, const uint8_t a, const uint8_t b){
	//we keep in S elements (x,y) such that T(a,b) + T(a+x,b) + T(a,b+y) + T(a+x,b+y) = 0
	//T is T[r][i]

	auto p = S.begin();
	auto S_end = S.end();
	while(p != S_end){
		//p = (x,y)
		uint8_t x = p->first;
		uint8_t y = p->second;

		//T(a,b) + T(a+x,b) + T(a,b+y) + T(a+x,b+y) = 0 ?
		//uint8_t res[32];
		bool iszero = true;
		for(unsigned int j = 0; j < 32; j++){
			uint8_t resj = Tri(a,b,j) ^ Tri(a^x,b,j) ^ Tri(a,b^y,j) ^ Tri(a^x,b^y,j);
			if(resj != 0){
				iszero = false;
				break;
			}
		}
		if(!iszero){
			p = S.erase(p);
		}
		else{
			p++;
		}
	}
}

std::set<pair<uint8_t, uint8_t>> computekerL(smallTable const & Tri){
	//Compute Ker L_i

	//Init K1 = [0,...,255]
	std::set<uint8_t> K1;
	for(unsigned int x = 0; x < 256; x++){
		K1.emplace(x);
	}
	for(unsigned int a = 0; a < 2; a++){
		for(unsigned int b = 0; b < 2; b++){
			filterkerL1(Tri,K1,a,b);
		}
	}
	//at this point, K1 should be equal to kerL1

	//Init K2 = [0,...,255]
	std::set<uint8_t> K2;
	for(unsigned int y = 0; y < 256; y++){
		K2.emplace(y);
	}
	for(unsigned int a = 0; a < 2; a++){
		for(unsigned int b = 0; b < 2; b++){
			filterkerL2(Tri,K2,a,b);
		}
	}
	//at this point, K2 should be equal to kerL2

	std::set<pair<uint8_t, uint8_t>> kerL;

	if(!(K1.size() == 256 && K2.size() == 256)){
		//We already have some elements in K
		std::set<pair<uint8_t, uint8_t>> K;
		for(auto const & x : K1){
			for(auto const & y : K2){
				K.emplace(x,y);
			}
		}
		unsigned int K_size = K.size();

		//Init kerL = { (x,y) such that x not in kerL1 and y not in kerL2}
		auto K1_end = K1.end();
		auto K2_end = K2.end();
		for(unsigned int x = 0; x < 256; x++){
			for(unsigned int y = 0; y < 256; y++){
				if(K1.find(x) == K1_end && K2.find(y) == K2_end){
					//if x not in kerL1 and y not in kerL2
					kerL.emplace(x,y);
				}
			}
		}
		bool kerFound = false;
		for(unsigned int a = 0; a < 2; a++){
			for(unsigned int b = 0; b < 2; b++){
				filter(Tri,kerL,a,b);
				if(kerL.size()+K_size == 256){
					//then we can stop here, we know that we already have Ker L
					kerFound = true;
					break;
				}
			}
			if(kerFound){
				break;
			}
		}
		//kerL should now contains the remaining elements of Ker L, complete it

		for(auto const & v : K){
			kerL.emplace(v);
		}
	}
	else{
		cout << "problem in the kernel computation" << endl;
		exit(0);
	}

	return kerL;
}

mat_GF2 completedKerBasis(std::set<pair<uint8_t, uint8_t>> kerL){
	//given a kernel kerL = { (x,y) such that x and y are 8bit values}
	//return a matrix (should be 16 x 16 in our case) such that 
	//the 8 top rows vectors are a basis of kerL
	//and the remaining rows are a base completion of GF(2)^16

	mat_GF2 M;
	M.SetDims(kerL.size(), 16); //M should be 256 x 16

	unsigned int indRow = 0;
	for(auto const p : kerL){
		uint8_t x = p.first;
		uint8_t y = p.second;
		auto & rowM = M[indRow];
		//one row of M is x0 ... x7 y0 ... y7
		for(unsigned int i = 0; i < 8; i++){
			rowM[i] = x & 1;
			x >>= 1;
			rowM[8+i] = y & 1;
			y >>= 1;
		}
		indRow++;
	}

	//echelonize M to get a basis of kerL and get which column are used as pivots (for base completion)
	//we know that rank(M)=8, so we can stop the echelonization sooner
	auto setPivots = echelonizeCustom(M, 8);
	auto setPivots_end = setPivots.end();

	//extract the top 8 rows of M
	mat_GF2 basis;
	basis.SetDims(16,16);
	for(unsigned int i = 0; i < 8; i++){
		basis[i] = M[i];
	}

	//complete the basis with unitary vectors
	unsigned int indrow = 8;
	for(unsigned int j = 0; j < 16; j++){
		if(setPivots.find(j) == setPivots_end){
			//if j is not a pivot, complete with (0 ... 0 1 0 ... 0) where 1 is at index j
			basis[indrow][j] = 1;
			indrow++;
		}
	}

	return basis;
}

mat_GF2 computeAprime(RoundFunction const & Tr){
	//compute inv(Aprime[r])

	mat_GF2 Aprime;
	Aprime.SetDims(0,256);
	//build Aprime by row blocks of size 8x256
	
	for(unsigned int i = 0; i < 32; i++){

		auto kerL = computekerL(Tr(i));
		auto M = completedKerBasis(kerL);
		auto Minv(inv(transpose(M)));

		mat_GF2 Mt;
		Mt.SetDims(8,16);
		//Mt is built from the last 8 rows of inv(M);
		for(unsigned int j = 0; j < 8; j++){
			Mt[j] = Minv[8+j];
		}
		
		if(i != 31){
			//build the row block i of Aprime which is 0|...|0|Mt|0|...|0
			mat_GF2 rowBlock;
			//begin with i 8x8 null matrix before the block Mt
			rowBlock.SetDims(8,i*8);
			//now the block Mt
			ref_mat_augment(rowBlock, Mt);
			//Complete with 8x8 null matrices
			mat_GF2 nullMat;
			nullMat.SetDims(8,(32-(i+2))*8);
			ref_mat_augment(rowBlock, nullMat);

			ref_mat_stack(Aprime, rowBlock);
		}
		else{
			//the last row block is treated differently
			//block 31 of Aprime is Mtr|0|...|0|Mtl where Mtr (resp. Mtl) are the right (resp. left) 8x8 part of Mt
			mat_GF2 Mtl, Mtr;
			Mtl.SetDims(8,8);
			Mtr.SetDims(8,8);
			for(unsigned int row = 0; row < 8; row++){
				auto & rowMtl = Mtl[row];
				auto & rowMtr = Mtr[row];
				const auto & rowMt = Mt[row];
				for(unsigned int col = 0; col < 8; col++){
					rowMtl[col] = rowMt[col];
					rowMtr[col] = rowMt[8+col];
				}
			}
			mat_GF2 nullMat;
			nullMat.SetDims(8,256-16);
			ref_mat_augment(Mtr, nullMat); //Mtr|0|...|0
			ref_mat_augment(Mtr, Mtl);	   //Mtr|0|...|0|Mtl
			ref_mat_stack(Aprime, Mtr);
		}
	}
	return Aprime;
}