#ifndef H_AffEQUI
#define H_AffEQUI

#include <vector>
#include <set>
#include <list>
#include <utility>
#include <algorithm>
#include <memory>
#include <tuple>
#include <iostream>
#include <cstdint>
#include <map>
#include "AES.hpp"
#include "GF2E_function.hpp"
#include "Subset.hpp"

class Data {
	public:
		Data() : n (0), m_sets(), m_vecs() {};
		Data(const unsigned int n_in);

		Data(Data const &) = default;
		Data(Data &&) = default;

		Data & operator=(Data const &) = default;
		Data & operator=(Data &&) = default;

		~Data() {};

		unsigned int n; //size of the sbox in bits

		Subset & DA() {return m_sets[0];};
		Subset const & DA() const {return m_sets[0];};

		Subset & DB() {return m_sets[1];};
		Subset const & DB() const {return m_sets[1];};

		Subset & DRs() {return m_sets[2];};
		Subset const & DRs() const {return m_sets[2];};

		Subset & CA() {return m_sets[3];};
		Subset const & CA() const {return m_sets[3];};

		Subset & CB() {return m_sets[4];};
		Subset const & CB() const {return m_sets[4];};

		Subset & NA() {return m_sets[5];};
		Subset const & NA() const {return m_sets[5];};

		Subset & NB() {return m_sets[6];};
		Subset const & NB() const {return m_sets[6];};

		Subset & UA() {return m_sets[7];};
		Subset const & UA() const {return m_sets[7];};

		Subset & UAinv() {return m_sets[8];};
		Subset const & UAinv() const {return m_sets[8];};

		Subset & UB() {return m_sets[9];};
		Subset const & UB() const {return m_sets[9];};

		std::vector<uint8_t> & Rs() {return m_vecs[0];};
		std::vector<uint8_t> const & Rs() const {return m_vecs[0];};

		uint8_t & Rs(std::vector<uint8_t>::size_type i) {return m_vecs[0][i];};
		uint8_t Rs(std::vector<uint8_t>::size_type i) const {return m_vecs[0][i];};

		std::vector<uint8_t> & A() {return m_vecs[1];};
		std::vector<uint8_t> const & A() const {return m_vecs[1];};

		uint8_t & A(std::vector<uint8_t>::size_type i) {return m_vecs[1][i];};
		uint8_t A(std::vector<uint8_t>::size_type i) const {return m_vecs[1][i];};

		std::vector<uint8_t> & Ainv() {return m_vecs[2];};
		std::vector<uint8_t> const & Ainv() const {return m_vecs[2];};

		uint8_t & Ainv(std::vector<uint8_t>::size_type i) {return m_vecs[2][i];};
		uint8_t Ainv(std::vector<uint8_t>::size_type i) const {return m_vecs[2][i];};

		std::vector<uint8_t> & B() {return m_vecs[3];};
		std::vector<uint8_t> const & B() const {return m_vecs[3];};

		uint8_t & B(std::vector<uint8_t>::size_type i) {return m_vecs[3][i];};
		uint8_t B(std::vector<uint8_t>::size_type i) const {return m_vecs[3][i];};

		std::vector<uint8_t> & Binv() {return m_vecs[4];};
		std::vector<uint8_t> const & Binv() const {return m_vecs[4];};

		uint8_t & Binv(std::vector<uint8_t>::size_type i) {return m_vecs[4][i];};
		uint8_t Binv(std::vector<uint8_t>::size_type i) const {return m_vecs[4][i];};

		void printState() const;

		void makeGuessA(const uint8_t x, const uint8_t y);
		//Guess A[x] = y and update the sets accordingly

		bool compRs(std::vector<uint8_t> const & Rsmin);

		bool incrementalBuild(std::vector<uint8_t> const & S, std::vector<uint8_t> const & Sinv, std::vector<uint8_t> const & Rsmin);
		bool buildB(std::vector<uint8_t> const & S, std::vector<uint8_t> const & Sinv, std::vector<uint8_t> const & Rsmin);
		bool buildA(std::vector<uint8_t> const & S, std::vector<uint8_t> const & Sinv, std::vector<uint8_t> const & Rsmin);

	private:
		std::vector<Subset> m_sets;
		std::vector<std::vector<uint8_t>> m_vecs;

};

Data findRepr(std::vector<uint8_t> const & S, const unsigned int n); //find the representative of S, n-bit sbox
std::vector<NTL::mat_GF2> affineEquivalence(std::map<std::vector<uint8_t>, std::tuple<uint8_t, std::vector<uint8_t>, std::vector<uint8_t>>> & T1, std::vector<uint8_t> const & S2, const unsigned int n);
//Return {a,A,b,B} such that B(S(Ax+a))+b = S2
//T1 is to be computed before with equivClassAES() and contains the lin. equiv. classes of S(x+a) where S is the AES Sbox

void testAffEqui(std::vector<NTL::mat_GF2> const & aAbB, std::vector<uint8_t> const & S1, std::vector<uint8_t> const & S2, unsigned int n);
//test if B(S1(Ax+a))+b == S2

std::map<std::vector<uint8_t>, std::tuple<uint8_t, std::vector<uint8_t>, std::vector<uint8_t>>> equivClassAES();
//Compute the lin. equiv. classes of the AES Sbox

std::vector<std::vector<NTL::mat_GF2>> selfEquivAES();
//Return a list of 2040 vector of the type {A1,A2,a2} such that A2(S(A1(x))+a2 = S where S is the AES sbox

#endif
