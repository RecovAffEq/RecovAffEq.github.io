#include "WBscheme.hpp"

using namespace std;


WBscheme::WBscheme(string filename, unsigned int rMax){
	//Read the tables of a masked rMax round AES from filename

	ifstream infile(filename, ios::in | ios::binary);
	if(!infile.is_open())
    {
        cout << "Failed to open file!\n";
        exit(EXIT_FAILURE);
    }

    m_T = vector<RoundFunction>(rMax);

    for(unsigned int r = 0; r < rMax; r++){
    	auto & RF = m_T[r];
		for(unsigned int i = 0; i < 32; i++){
			auto & sTable = RF(i);
			// for(unsigned int x = 0; x < 256; x++){
			// 	for(unsigned int y = 0; y < 256; y++){
			// 		for(unsigned int j = 0; j < 32; j++){
			// 			infile.read((char*)& sTable(x,y,j), sizeof(uint8_t));
			// 		}
			// 	}
			// }
			infile.read((char*) sTable(0), 2097152*sizeof(uint8_t));
		}
	}
}

vector<uint8_t> WBscheme::encrypt(vector<uint8_t> const & m){
	//encrypt m using this scheme
	
	unsigned int rMax = m_T.size();

	vector<uint8_t> x(m);
	for(unsigned int r = 0;  r < rMax; r++){
		vector<uint8_t> tmp(32,0);	//tmp = Fr(x)
		auto const & Tr = m_T[r];

		for(unsigned int i = 0; i < 32; i++){
			auto const & Tri = Tr(i);
			for(unsigned int j = 0; j < 32; j++){
				tmp[j] ^= Tri(x[i], x[(i+1)%32], j);	//sum_i(T[r][i])
			}
		}
		x = move(tmp);
	}

	return x;
}