#include "AES.hpp"
#include <ctime>
#include <vector>
#include <set>
#include <iostream>
#include <cstdint>
#include "GF2E_function.hpp"
#include "table.hpp"

using namespace std;
using namespace NTL;

int main()
{
	auto g = AES_modulus();
	GF2E::init(g);
	GF2X::HexOutput = 1;

	clock_t start;
	double duration;
	start = clock();

	vector<uint8_t> key = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
	generateTable("AESTable.tab", 10, key);
	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " time : " << duration << endl;
	
}