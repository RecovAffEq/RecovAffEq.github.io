#include "breakWB.hpp"


using namespace std;
using namespace NTL;

int main()
{	

	// WBscheme T("AESTable.tab", 10);
	// breakOneRound(T(0));

	auto secret = breakWhiteBoxAgain("AESTable.tab", "FoundEncodings.txt");
	
}