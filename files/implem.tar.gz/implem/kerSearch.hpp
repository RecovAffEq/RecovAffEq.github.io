#ifndef H_KERSEARCH
#define H_KERSEARCH

#include "AES.hpp"
#include <ctime>
#include <vector>
#include <set>
#include <utility>
#include <iostream>
#include <fstream>
#include <cstdint>
#include <unordered_set>
#include <unordered_map>
#include <map>

#include "RoundFunction.hpp"
#include "GF2E_function.hpp"



void filterKerL1(smallTable const & Tri, std::set<uint8_t> & K1, const uint8_t a, const uint8_t b);
//We want to keep elements x of K1 such that 
// f : y -> T(a+x,b+y) + T(a,b+y) is constant

void filterKerL2(smallTable const & Tri, std::set<uint8_t> & K2, const uint8_t a, const uint8_t b);
//We want to keep elements y in K2 such that
// f : x -> T(a+x,b+y) + T(a+x,b) is constant

void filter(smallTable const & Tri, std::set<std::pair<uint8_t, uint8_t>> & S, const uint8_t a, const uint8_t b);
//we keep in S elements (x,y) such that T(a,b) + T(a+x,b) + T(a,b+y) + T(a+x,b+y) = 0
//T is T[r][i]

std::set<std::pair<uint8_t, uint8_t>> computekerL(smallTable const & Tri);
//Compute Ker L_i

NTL::mat_GF2 completedKerBasis(std::set<std::pair<uint8_t, uint8_t>> kerL);

NTL::mat_GF2 computeAprime(RoundFunction const & Tr);

#endif