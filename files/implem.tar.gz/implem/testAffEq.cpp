#include "AffEqui.hpp"
#include <vector>
#include <set>
#include <utility>
#include <tuple>
#include <cstdint>
#include <map>
#include "aux_function.hpp"
#include "GF2E_function.hpp"
#include <ctime>
#include <iostream>

using namespace std;
using namespace NTL;

int main()
{
	clock_t start;
	double duration;
	start = clock();

	vector<uint8_t> S1 = {12, 5, 6, 11, 9, 0, 10, 13, 3, 14, 15, 8, 4, 7, 1, 2}; //PRESENT sbox
	unsigned int n = 4;
	unsigned int pow2n = (1<<n);

	start = clock();
	cout << "Computing the lin. equiv. classes of the PRESENT Sbox... " << flush;
	//since the AES sbox doesn't change, we can compute all of the lin. equiv. class of S1(x+a) once
	map<vector<uint8_t>, tuple<uint8_t, vector<uint8_t>, vector<uint8_t>>> T1;
	for(unsigned int a = 0; a < pow2n; a++){
		//compute S1(x+a)
		vector<uint8_t> S1xa(pow2n);
		for(unsigned int x = 0; x < pow2n; x++){
			S1xa[x] = S1[x^a];
		}
		//compute the representative of the lin. equiv. class of S1(x+a)
		// cout << "compute the representative of the lin. equiv. class of S1(x+" << (unsigned int) a << ")..." << endl;
		Data repr = findRepr(S1xa,n);
		//store the corresponding (a,A,Binv) in T1 indexed by Rs
		T1[repr.Rs] = make_tuple(a,repr.A, repr.Binv);
	}
	cout << endl << "Testing..." << endl;
	for(unsigned int r = 0; r < 100; r++){
		//generate S2 = BSA
		mat_GF2 A(random_invertible_mat_GF2(n));
		mat_GF2 B(random_invertible_mat_GF2(n));
		mat_GF2 amat(random_mat_GF2(n,1));
		mat_GF2 bmat(random_mat_GF2(n,1));
		unsigned int vala=0, valb=0;

		for(unsigned int b = 0; b < n; b++){
			if(amat[b][0] == 1){
				vala ^= (1<<b);
			}
			if(bmat[b][0] == 1){
				valb ^= (1<<b);
			}
		}

		vector<uint8_t> tableA(pow2n);
		vector<uint8_t> tableB(pow2n);

		for(unsigned int x = 0; x < (pow2n); x++){
			mat_GF2 xmat;
			xmat.SetDims(4,1);
			for(unsigned int b = 0; b < n; b++){
				xmat[b][0] = (x>>b)&1;
			}
			mat_GF2 yA(A*xmat);
			mat_GF2 yB(B*xmat);

			unsigned int valyA = 0;
			unsigned int valyB = 0;
			for(unsigned int b = 0; b < n; b++){
				if(yA[b][0] == 1){
					valyA ^= (1<<b);
				}
				if(yB[b][0] == 1){
					valyB ^= (1<<b);
				}
			}
			tableA[x] = valyA;
			tableB[x] = valyB;
		}
		
		vector<uint8_t> S2(pow2n);
		for(unsigned int x = 0; x < (pow2n); x++){
			S2[x] = tableB[S1[tableA[x]^vala]]^valb;
		}
		auto list_aAbB = affineEquivalence(T1,S2,n);
		// bool solutionexist = false;
		for(auto const & aAbB : list_aAbB){
			// if(aAbB[0] == amat && aAbB[1] == A && aAbB[2] == bmat && aAbB[3] == B){
			// 	solutionexist = true;
			// 	break;
			// }
			if(aAbB[0] == amat){
				cout << "1";
			}
			else{
				cout << "0";
			}

			if(aAbB[1] == A){
				cout << "1";
			}
			else{
				cout << "0";
			}

			if(aAbB[2] == bmat){
				cout << "1";
			}
			else{
				cout << "0";
			}

			if(aAbB[3] == B){
				cout << "1";
			}
			else{
				cout << "0";
			}
			cout << ".";
		}
		cout << endl;
		// if(!solutionexist){
		// 	cout << "The solution is not in the list" << endl;
		// }
	}
	cout << endl;

	duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
	cout << " time affineeq : " << duration << endl;
}