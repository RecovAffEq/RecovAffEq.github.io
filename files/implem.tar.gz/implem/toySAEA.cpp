#include "SAEA.hpp"

using namespace std;
using namespace NTL;

int main()
{	
	// auto T = ToyTable();
	// cout << T(0) << endl;
	// T.computeEquivalent();

	uint8_t d[4][4] = {{1,0,1,0},{0,0,1,1},{1,0,0,1},{0,0,0,0}};
	mat_GF2 M; M.SetDims(4,4);
	for(unsigned int i = 0; i < 4; i++){
		for(unsigned int j = 0; j < 4; j++){
			M[i][j] = d[i][j];
		}
	}
	
	cout << M << endl << endl;
	auto setPivot = reducedEchelonizeWithPivot(M);

	cout << M << endl;
	for(auto const & p : setPivot){
		cout << p << " ";
	}
	cout << endl;
}