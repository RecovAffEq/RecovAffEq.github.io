#ifndef H_ROUNDFUNCTION
#define H_ROUNDFUNCTION

#include <array>
#include "smallTable.hpp"

class RoundFunction{

	public:
		RoundFunction() : m_Tr(){};

		smallTable & operator()(unsigned int i) {return m_Tr[i];};
		smallTable const & operator()(unsigned int i) const {return m_Tr[i];};



	private:

		std::array<smallTable, 32> m_Tr;
};


#endif