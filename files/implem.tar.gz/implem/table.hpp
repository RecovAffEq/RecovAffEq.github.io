#ifndef H_TABLE
#define H_TABLE

#include <ctime>
#include <NTL/mat_GF2.h>
#include <vector>
#include <cstdint>
#include <string>
#include <fstream>
#include "AES.hpp"

void generateTable(std::string filename, unsigned int Rmax, std::vector<uint8_t> key);
//Generate the table for Rmax rounds of masked AES using key in filename
//Expected time is roughly 30min for a 10 rounds AES
//Will also generate a file secret_encodings.txt containing the first encoding A0 and the output external encoding M_out
//in a format such that one can easoly checkk if the attack recovers the correct encodings
//The input external encoding M_in is not used in the attack and would only be given in a matrix format
//so it's not generated, and the attack will output A0 which is sufficient to recover M_in if provided afterward

#endif