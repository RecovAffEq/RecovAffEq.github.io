#ifndef H_WBSCHEME
#define H_WBSCHEME

#include <vector>
#include <iostream>
#include <fstream>
#include "RoundFunction.hpp"

class WBscheme{
	//Class which will contains the tables of the scheme as a vector of RoundFunction
	public:

		WBscheme() : m_T(10){};
		WBscheme(std::string filename, unsigned int rMax); //Read the tables of a masked rMax round AES from filename

		//Access the r-th round function tables
		RoundFunction & operator()(unsigned int r) {return m_T[r];}; 
		RoundFunction const & operator()(unsigned int r) const {return m_T[r];};

		std::vector<uint8_t> encrypt(std::vector<uint8_t> const & m); //encrypt m using this scheme


	private:
		std::vector<RoundFunction> m_T;
};


#endif