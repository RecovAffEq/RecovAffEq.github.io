#ifndef H_ATTACK
#define H_ATTACK


#include <vector>
#include <set>
#include <list>
#include <utility>
#include <algorithm>
#include <tuple>
#include <iostream>
#include <cstdint>
#include <map>
#include <ctime>

#include "RoundFunction.hpp"
#include "kerSearch.hpp"
#include "AffEqui.hpp"
#include "GF2E_function.hpp"
#include "AES.hpp"

std::tuple<std::vector<uint8_t>,NTL::mat_GF2,NTL::mat_GF2> computePoHoSoG(RoundFunction const & Tr, NTL::mat_GF2 const & Apinv, const unsigned int i);
//sum(T[r][j]) o inv(Aprime[r])(0 ... 0 xi 0 ... 0) where xi takes all 8bit values
//can be written as a map of the form PoHoSoG from GF(2)^8 to itself
//return this map PoHoSoG as a full table

std::vector<std::pair<NTL::mat_GF2,NTL::mat_GF2>> computeOneCandidate(RoundFunction const & Tr, NTL::mat_GF2 const & Apinv,
													std::map<std::vector<uint8_t>, std::tuple<uint8_t, std::vector<uint8_t>, std::vector<uint8_t>>> & linEqClass);
//Compute a candidate for B1,...,B32 on the last round
//return a vector listBi such that listBi[i] = {Bi, bi}, (direction, center)

std::vector<std::vector<std::pair<NTL::mat_GF2, NTL::mat_GF2>>> computeCandidates(RoundFunction const & Tr, 
															NTL::mat_GF2 const & Apinv,
															std::map<std::vector<uint8_t>,std::tuple<uint8_t,std::vector<uint8_t>,std::vector<uint8_t>>> & linEqClass,
															std::vector<std::vector<NTL::mat_GF2>> const & listEquiv);
//Compute all candidates for Br[0]...Br[31]
//return a vector listCandidates such that listCandidates[i] contains all 2040 candidates {Bi, bi}

NTL::mat_GF2 mat_SumTjx(RoundFunction const & Tr, std::vector<uint8_t> const & x);
//Return a 256x1 mat_GF2 representing y = sum_i(Tr[i])(x)

std::vector<uint8_t> ytFromOneActiveByte(RoundFunction const & Tr, 
								 NTL::mat_GF2 const & matv,
								 unsigned int indxi,
								 NTL::mat_GF2 const & Aprime_rp1,
								 NTL::mat_GF2 const & invAprime_r,
								 std::vector<uint8_t> const & iblockB);
//Compute yt[iblockB] from one active byte matv at position indxi


std::vector<std::pair<NTL::mat_GF2,NTL::mat_GF2>> searchBlock(RoundFunction const & Tr,
															  NTL::mat_GF2 const & Aprime_rp1,
															  NTL::mat_GF2 const & invAprime_r,
															  std::vector<std::vector<std::pair<NTL::mat_GF2,NTL::mat_GF2>>> const & listCandidateBi,
															  std::vector<std::vector<std::pair<NTL::mat_GF2,NTL::mat_GF2>>> const & listCandidateCi,
															  unsigned int numBlock);
//search for the numBlock-th block in B and C
//The blocks are indexed following the blocks after the MixColumns on B,
// with the corresponding blocks of C through ShiftRows
//For example, the block 0 is B0 B1 B2 B3 C0 C5 C10 C15
//			   the block 1 is B4 B5 B6 B7 C4 C9 C14 C3

NTL::mat_GF2 zFromOneActiveByte(RoundFunction const & Tr, NTL::mat_GF2 const & invAprime_r, unsigned int ind, NTL::mat_GF2  const & x, NTL::mat_GF2 const & cst);
//get z = Tr( inv(A'r) * x) where x have one active byte at index ind

NTL::mat_GF2 buildEquivM(RoundFunction const & Tr, 
					     NTL::mat_GF2 const & invAprime,
					     std::vector<std::pair<NTL::mat_GF2,NTL::mat_GF2>> const & candidateBi);
//Return an equivalent M


#endif