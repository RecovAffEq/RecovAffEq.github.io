#include "Attack.hpp"
#include "sparsepp.hpp"

using namespace std;
using namespace NTL;

tuple<vector<uint8_t>,mat_GF2,mat_GF2> computePoHoSoG(RoundFunction const & Tr, mat_GF2 const & Apinv, const unsigned int i){
	//sum(T[r][j]) o inv(Aprime[r])(0 ... 0 xi 0 ... 0) where xi takes all 8bit values
	//can be written as a map of the form PoHoSoG from GF(2)^8 to itself
	//return this map PoHoSoG as a full table, the matrix of P and the center used as a tuple {PHSG,matP,center}

	//compute sum(T[r][j]) o inv(Aprime[r])(0 ... 0 xi 0 ... 0) where xi takes all 8bit values
	mat_GF2 sumMat;
	sumMat.SetDims(256,256);
	for(unsigned int x = 0; x < 256; x++){
		//be Y = inv(Aprime[r])(0 ... 0 xi 0 ... 0)
		//Y can be written Y = A.xi where A is a 256x8 matrix obtained from the i-th 8-column-block of Apinv
		//we need to store Y as a vector of 32 8bit values i.e. Y = (y1 ... y32)
		vector<uint8_t> Y(32);

		for(unsigned int j = 0; j < 32; j++){
			//we will compute yj (8bit)
			uint8_t yj=0;
			for(unsigned int b = 0; b < 8; b++){
				//for each bit of yj
				// yj[b] = A[8*j+b].x
				const auto & rowA = Apinv[8*j+b];
				uint8_t res=0;
				for(unsigned int bx = 0; bx < 8; bx++){
					//for each bit of x
					res ^= conv<unsigned int>(rowA[8*i+bx]) & ((x >> bx) & 1);
				}
				yj ^= (res << b);
			}
			Y[j] = yj;
		}

		//compute sum(T[r][j])(Y)
		//the 256 output bits are stored as a vector of 32 uint8
		vector<uint8_t> sum(32,0);
		for(unsigned int j = 0; j < 32; j++){
			auto const & Trj = Tr(j);
			// auto const res = T[j][Y[j]][Y[(j+1)%32]];
			for(unsigned int b = 0; b < 32; b++){
				sum[b] ^= Trj(Y[j], Y[(j+1)%32], b);
			}
		}

		//set the correponding row of the matrix to the GF2 vector corresponding to this sum
		auto & row = sumMat[x];
		for(unsigned int j = 0; j < 32; j++){
			uint8_t s = sum[j];
			for(unsigned int b = 0; b < 8; b++){
				row[8*j+b] = (s >> b)&1;
			}
		}
	}

	//at this point, sumMat is a matrix where each row is
	//the image of (0 ... 0 xi 0 ... 0) through sum(T[r][j]) o inv(Aprime[r])
	//the resulting matrix should be of rank 9 at most (8 iif one row is zero)
	//leading to an affine subspace of dimension 8
	//we want to get the underlying linear subspace
	//for that, set the first row to be the center of the affine space
	//then the underlying linear subspace is obtained by xoring the first row with each rows of the matrix

	auto center = sumMat[0];
	for(unsigned int x = 0; x < 256; x++){
		sumMat[x] += center;
	}

	//extract a basis
	mat_GF2 matBasis(sumMat); //keep sumMat
	//echelonize and keep the index of the pivots. We know that the matrix is of rank 8
	auto pivotIndex = echelonizeCustom(matBasis,8);
	//extract the first 8 rows (basis) and express this basis as some vector<uint32_t>
	//basis[x] = {w1,...,w8} where each wi is 32bit value
	vector<vector<uint32_t>> basis(8,vector<uint32_t>(8));
	for(unsigned int x = 0; x < 8; x++){
		const auto & v = matBasis[x];
		for(unsigned int b = 0; b < 8; b++){
			//compute wb := basis[x][b]
			uint32_t wb = 0;
			for(unsigned int bv = 0; bv < 32; bv++){
				if(v[32*b+bv] == 1){
					wb ^= (1 << bv);
				}
			}
			basis[x][b] = wb;
		}
	}

	//generate a map from this subspace to GF(2)^8
	map<vector<uint32_t>,uint8_t> P;
	for(unsigned int x = 0; x < 256; x++){
		//for each vector in GF(2)^8
		//compute the corresponding element of our subspace
		vector<uint32_t> elmt(8,0);
		for(unsigned int b = 0; b < 8; b++){
			//for each bit of x
			if((x >> b)&1){
				for(unsigned int j = 0; j < 8; j++){
					//for each 32bit word of elmt
					elmt[j] ^= basis[b][j];
				}
			}
		}
		P[elmt] = x;
	}

	//sum(T[r][j]) o inv(Aprime[r]) is of the form HoSoG where H,G are invertible affine mapping
	//at this point, we have determined an affine map P:=(P + center) such that PoHoSoG is a mapping from GF(2)^8 to itself
	//we just need to explicitly create this mapping
	//we have x -> v:=sumMat[x] -> P[v8]=:PHSG(x) (where v8 is the underlying 8x32bit representation of sumMat[x])
	vector<uint8_t> PHSG(256);
	for(unsigned int x = 0; x < 256; x++){
		//for each row of sumMat
		const auto & v = sumMat[x];
		//compute the underlying 8x32bit vector
		vector<uint32_t> v8(8);
		for(unsigned int j = 0; j < 8; j++){
			//for each 32bit word
			uint32_t w = 0;
			for(unsigned int b = 0; b < 32; b++){
				if(v[32*j+b] == 1){
					w ^= (1<<b);
				}
			}
			v8[j] = w;
		}
		PHSG[x] = P[v8];
	}

	//We also want to create the matrix of P
	//Complete matBasis to form a basis of GF(2)^256, actually the first 8 rows are a basis of our subspace, the other are zeros
	unsigned int indBasis = 8;
	auto const pivotIndex_end = pivotIndex.end();
	for(unsigned int i = 0; i < 256; i++){
		if(pivotIndex.find(i) == pivotIndex_end){
			//if column i was not a pivot, then the i-th canonical vector can be used to complete this basis
			matBasis[indBasis][i] = 1;
			indBasis++;
		}
	}
	//transpose(matBasis) is the change of basis matrix, but we want it's inverse
	matBasis = inv(transpose(matBasis));
	//the matrix of P is the first 8 rows of matBasis
	mat_GF2 matP;
	matP.SetDims(8,256);
	for(unsigned int i = 0; i < 8; i++){
		matP[i] = matBasis[i];
	}
	mat_GF2 matC; //matric of the center, actually center is a vec_GF2, not a mat_GF2
	matC.SetDims(1,256);
	matC[0] = center;
	matC = transpose(matC);

	return {PHSG,matP,matC};
}
vector<pair<mat_GF2,mat_GF2>> computeOneCandidate(RoundFunction const & Tr, mat_GF2 const & Apinv,
												 map<vector<uint8_t>, tuple<uint8_t, vector<uint8_t>, vector<uint8_t>>> & linEqClass){
	//Compute a candidate for B1,...,B32 
	//Apinv is inv(Aprime[r])
	//linEqClass is the lin. equiv. classes of the AES sbox
	//return a vector listBi such that listBi[i] = {Bi, bi}, (direction, center)


	vector<pair<mat_GF2,mat_GF2>> listBi(32);

	for(unsigned int i = 0; i < 32; i++){
		cout <<  i << " " << flush;
		
		vector<uint8_t> PHSG;
		tie(PHSG,ignore,ignore) = computePoHoSoG(Tr, Apinv, i);
		auto aAbB = affineEquivalence(linEqClass,PHSG,8);

		listBi[i] = make_pair(aAbB[1], aAbB[0]);
	}
	cout << endl;
	return listBi;
}

vector<vector<pair<mat_GF2,mat_GF2>>> computeCandidates(RoundFunction const & Tr,
														mat_GF2 const & Apinv,
														map<vector<uint8_t>,tuple<uint8_t,vector<uint8_t>,vector<uint8_t>>> & linEqClass,
														vector<vector<mat_GF2>> const & listEquiv){
	//Compute all candidates for Br[0]...Br[31]
	//return a vector listCandidateBi such that listCandidateBi[i] contains all 2040 candidates {Bi, bi}

	auto listFirstBi = computeOneCandidate(Tr,Apinv,linEqClass); //listBi[i] = {Bi,bi}
	//We have a candidate for each {Bi,bi}
	//all other can be derived using the self equivalence relation of the aes sbox
	//listEquiv contains all {A1,A2,a2} such that S(x) = A2(S(A1(x)))+a2 i.e. S = A2 o S o A1
	vector<vector<pair<mat_GF2,mat_GF2>>> listCandidateBi(32,
		   vector<pair<mat_GF2,mat_GF2>>(listEquiv.size()));

	for(unsigned int i = 0; i < 32; i++){

		mat_GF2 Bi = listFirstBi[i].first;
		mat_GF2 bi = listFirstBi[i].second;
		unsigned int j = 0;
		for(auto const & A1A2a2 : listEquiv){
			auto const & A1 = A1A2a2[0];
			//Then we have a new candidate {Bi',bi'} for {Bi,bi} as
			// Bi' = A1 o Bi = A1.Bi
			// bi' = A1.bi
			listCandidateBi[i][j] = make_pair(A1*Bi, A1*bi);
			j++;
		}
	}

	return listCandidateBi;
}

mat_GF2 mat_SumTjx(RoundFunction const & Tr, vector<uint8_t> const & x){
	//Return a 256x1 mat_GF2 representing y = sum_i(Tr[i])(x)

	//Compute y = sum_i(Tr[i])(x)
	vector<uint8_t> y(32,0);
	for(unsigned int i = 0; i < 32; i++){
		auto const & Tri = Tr(i);
		for(unsigned int j = 0; j < 32; j++){
			y[j] ^= Tri(x[i], x[(i+1)%32], j);
		}
	}
	//Compute the corresponding 256x1 vector
	mat_GF2 maty; maty.SetDims(256,1);
	for(unsigned int i = 0; i < 32; i++){
		uint8_t yi = y[i];
		for(unsigned int b = 0; b < 8; b++){
			maty[8*i+b][0] = yi&1;
			yi >>= 1;
		}
	}

	return maty;
}

vector<uint8_t> ytFromOneActiveByte(RoundFunction const & Tr, 
								 mat_GF2 const & matv,
								 unsigned int indxi,
								 mat_GF2 const & Aprime_rp1,
								 mat_GF2 const & invAprime_r,
								 vector<uint8_t> const & iblockB){

	//Compute yt[iblockB] from one active byte matv at position indxi

	//Compute the matrix of x where x[0] = v, x[i] = cst otherwise
	mat_GF2 cst = matGF2FromUint8(0);
	mat_GF2 x; x.SetDims(256,1);

	for(unsigned int b = 0; b < 8; b++){
		x[indxi*8 + b][0] = matv[b][0];
	}

	//compute w = invAprim[r]*x
	mat_GF2 matw = invAprime_r*x;

	//compute the 32*8 bits vector representing w
	vector<uint8_t> w(32);
	for(unsigned int i = 0; i < 32; i++){
		uint8_t ww = 0;
		for(unsigned int b = 0; b < 8; b++){
			if(matw[8*i+b][0] == 1){
				ww ^= (1<<b);
			}
		}
		w[i] = move(ww);
	}

	//Compute the 256x1 matrix corresponding to y = sum_i(Tr[i])(w)
	mat_GF2 maty = mat_SumTjx(Tr, w);

	//Compute yt = Aprime_r+1*y
	mat_GF2 matyt(Aprime_rp1*maty);


	//Extract yt[0,1,2,3]
	vector<uint8_t> yt(4);
	for(unsigned int i = 0; i < 4; i++){
		uint8_t yti = 0;
		unsigned int ib = iblockB[i];
		for(unsigned int b = 0; b < 8; b++){
			if(matyt[8*ib+b][0] == 1){
				yti ^= (1<<b);
			}
		}
		yt[i] = move(yti);
	}

	return yt;
}

vector<pair<mat_GF2,mat_GF2>> searchBlock(RoundFunction const & Tr,
				 mat_GF2 const & Aprime_rp1,
				 mat_GF2 const & invAprime_r,
				 vector<vector<pair<mat_GF2,mat_GF2>>> const & listCandidateBi,
				 vector<vector<pair<mat_GF2,mat_GF2>>> const & listCandidateCi,
				 unsigned int numBlock){

	
	//search for the numBlock-th block in B and C
	//The blocks are indexed following the blocks after the MixColumns on B,
	// with the corresponding blocks of C through ShiftRows
	//For example, the block 0 is B0 B1 B2 B3 C0 C5 C10 C15
	//			   the block 1 is B4 B5 B6 B7 C4 C9 C14 C3

	//The comments and name of variables will be based on the block 0 for easier understanding

	//First compute the index on B and C for this block
	vector<uint8_t> iblockB(4);
	vector<uint8_t> iblockC(4);
	for(unsigned int i = 0; i < 4; i++){
		iblockB[i] = 4*numBlock+i;

		iblockC[i] = (4*numBlock + (5*i))%16 + 16*(numBlock/4);
	}

	auto const sboxAES = AES_SBOX();
	auto const tableMultiply = GF256TableMultiply();

	//////////////////////////////////////////////////////
	//For 4 values of x0
	//Compute the corresponding (yt0, yt1, yt2, yt3)
	//////////////////////////////////////////////////////
	unsigned int ind_ci = 0; //match with C0
	unsigned int nbDiff = 4;
	vector<uint32_t> vecmatch(8);
	{
		vector<vector<uint8_t>> yt0123(nbDiff+1);
		//Generate random values
		vector<mat_GF2> vecMatv(nbDiff+1);
		for(unsigned int v = 0; v < nbDiff+1; v++){
			vecMatv[v] = random_mat_GF2(8,1);
		}

		for(unsigned int v = 0; v < nbDiff+1; v++){
			yt0123[v] = ytFromOneActiveByte(Tr, vecMatv[v], iblockC[ind_ci], Aprime_rp1, invAprime_r, iblockB);
		}

		//////////////////////////////////////////////////////
		//Compute the difference column vector such that Dyt0123[i] = yt0123[0] ^ yt0123[i+1]
		//////////////////////////////////////////////////////
		// cout << "Computing the differences in yt0123..." << endl;
		vector<vector<mat_GF2>> Dyt0123(nbDiff);
		for(unsigned int i = 0; i < nbDiff; i++){
			vector<mat_GF2> dyt0123(4);
			for(unsigned int j = 0; j < 4; j++){
				uint8_t diff = yt0123[0][j] ^ yt0123[i+1][j];

				dyt0123[j] = matGF2FromUint8(diff);
			}

			Dyt0123[i] = move(dyt0123);
		}

		//////////////////////////////////////////////////////
		//Compute all the possible 3 differences in xt0 
		//Where xt0 = S(C0(xt))
		//////////////////////////////////////////////////////
		auto const & candidateC0 = listCandidateCi[iblockC[ind_ci]];
		unsigned int nbSelfEquiv = candidateC0.size();
		vector<vector<uint8_t>> Dxt0(nbSelfEquiv, vector<uint8_t>(nbDiff));
		for(unsigned int ic = 0; ic < nbSelfEquiv; ic++){

			auto const & C0 = candidateC0[ic].first;
			auto const & c0 = candidateC0[ic].second;

			auto & Dxt0ic = Dxt0[ic];

			//We will computes differences from 4 values of x0
			//first compute xt0 for the first value (which will be used to compute the differences)
			//xti_0 = S(Ci(vecMatv[0]))
			uint8_t xt0_0 = sboxAES[uint8FromMatGF2(C0*vecMatv[0] + c0)];

			for(unsigned int x0 = 1; x0 < nbDiff+1; x0++){
				//for each values of x0
				//compute xti = S(Ci(x0)) = S(Ci.x0 + ci)
				uint8_t xt0 = sboxAES[uint8FromMatGF2(C0*vecMatv[x0] + c0)];

				//compute the differences
				uint8_t dxt0 = xt0_0 ^ xt0;

				Dxt0ic[x0-1] = move(dxt0);
			}
		}

		//////////////////////////////////////////////////////
		//Match each Bi
		//////////////////////////////////////////////////////
		clock_t start = clock();
		cout << "Matching..." << flush;
		 
		for(unsigned int indBi = 0; indBi < 4; indBi++){
			auto const & candidateBi = listCandidateBi[iblockB[indBi]];

			//Compute DzindB[i] = MC(dxt0[0]) ^ MC(dxt0[i+1])
			auto const & multcoeff = tableMultiply[MC_intCoeff(indBi, ind_ci)];

			spp::sparse_hash_map<uint32_t, uint32_t> mapDz;
			mapDz.reserve(nbSelfEquiv);
			for(unsigned int ic = 0; ic < nbSelfEquiv; ic++){
				auto & Dxt0ic = Dxt0[ic];

				uint32_t dz = multcoeff[Dxt0ic[0]];
				for(unsigned int v = 1; v < nbDiff; v++){
					dz <<= 8;
					dz ^= multcoeff[Dxt0ic[v]];
				}

				mapDz[dz] = ic;
			}
			auto mapDz_end = mapDz.end();

			//For each candidate of Bi, check if Bi(dyt[i]) == dzi
			for(unsigned int ib = 0; ib < nbSelfEquiv; ib++){
				auto const & Bi = candidateBi[ib].first;

				uint32_t dz = uint8FromMatGF2(Bi*Dyt0123[0][indBi]);
				for(unsigned int v = 1; v < nbDiff; v++){
					dz <<= 8;
					dz ^= uint8FromMatGF2(Bi*Dyt0123[v][indBi]);
				}

				auto it_dz = mapDz.find(dz);
				if(it_dz != mapDz_end){
					vecmatch[indBi] = ib;
					if(indBi == 3){
						vecmatch[4] = it_dz->second;
					}
				}
			}
		}
		double duration = (clock() - start)/ (double) CLOCKS_PER_SEC;
		cout << " " << duration << "s" << endl;
	}
	

	auto const & B0 = listCandidateBi[iblockB[0]][vecmatch[0]].first;

	for(ind_ci = 1; ind_ci < 4; ind_ci++){
		vector<vector<uint8_t>> yt0123(nbDiff+1);
		//Generate random values
		vector<mat_GF2> vecMatv(nbDiff+1);
		for(unsigned int v = 0; v < nbDiff+1; v++){
			vecMatv[v] = random_mat_GF2(8,1);
		}

		//Compute the differences in yt0
		//Value from which differences will be computed
		uint8_t yt0_from = ytFromOneActiveByte(Tr, vecMatv[0], iblockC[ind_ci], Aprime_rp1, invAprime_r, iblockB)[0];
		vector<uint8_t> Dyt0(nbDiff);
		for(unsigned int v = 1; v < nbDiff+1; v++){
		
			Dyt0[v-1] = yt0_from ^ ytFromOneActiveByte(Tr, vecMatv[v], iblockC[ind_ci], Aprime_rp1, invAprime_r, iblockB)[0];
		}

		//Compute the differences dz0 = B0*dyt0;
		uint32_t dz0 = uint8FromMatGF2(B0*matGF2FromUint8(Dyt0[0]));
		for(unsigned int v = 1; v < nbDiff; v++){
			dz0 <<= 8;

			dz0 ^= uint8FromMatGF2(B0*matGF2FromUint8(Dyt0[v]));
		}

		//Search the matching Ci
		auto const & multcoeff = tableMultiply[MC_intCoeff(0, ind_ci)];
		auto const & candidateCi = listCandidateCi[iblockC[ind_ci]];
		unsigned int nbSelfEquiv = candidateCi.size();
		for(unsigned int ic = 0; ic < nbSelfEquiv; ic++){
			//For each candidate
			auto const & Ci = candidateCi[ic].first;
			auto const & ci = candidateCi[ic].second;

			//Compute dzi = MC(S(Ci(x0))) ^ MC(S(Ci(xi)))
			uint8_t z0_from = multcoeff[sboxAES[uint8FromMatGF2(Ci*vecMatv[0] + ci)]];
			
			uint32_t testing_dz0 = z0_from ^ multcoeff[sboxAES[uint8FromMatGF2(Ci*vecMatv[1] + ci)]];
			for(unsigned int v = 2; v < nbDiff+1; v++){
				testing_dz0 <<= 8;

				testing_dz0 ^= z0_from ^ multcoeff[sboxAES[uint8FromMatGF2(Ci*vecMatv[v] + ci)]];
			}

			if(testing_dz0 == dz0){
				vecmatch[4+ind_ci] = ic;
				break;
			}
		}
	}

	vector<pair<mat_GF2,mat_GF2>> goodMatrices(8);
	cout << "Match C0 : " << vecmatch[4] << endl;
	for(unsigned int i = 0; i < 4; i++){
		goodMatrices[i] = listCandidateBi[iblockB[i]][vecmatch[i]];
		goodMatrices[i+4] = listCandidateCi[iblockC[i]][vecmatch[i+4]];
	}
	
	return goodMatrices;
}

mat_GF2 zFromOneActiveByte(RoundFunction const & Tr, mat_GF2 const & invAprime_r, unsigned int ind, mat_GF2  const & x, mat_GF2 const & cst){

	//get z = Tr( inv(A'r) * x) where x have one active byte at index ind

	//Build the full column vector of x0 then apply inv(A'r)
	mat_GF2 matx; matx.SetDims(0,1);
	for(unsigned int i = 0; i < ind; i++){
		ref_mat_stack(matx, cst);
	}
	ref_mat_stack(matx, x);
	for(unsigned int i = ind+1; i < 32; i++){
		ref_mat_stack(matx, cst);
	}
	matx = invAprime_r*matx;
	//Get the corresponding 32*8bit vector
	vector<uint8_t> vecx(32);
	for(unsigned int i = 0; i < 32; i++){
		uint8_t xi = 0; 
		for(unsigned int b = 0; b < 8; b++){
			if(matx[8*i+b][0] == 1){
				xi ^= (1<<b);
			}
		}
		vecx[i] = move(xi);
	}
	//Compute the image through the tables
	return mat_SumTjx(Tr, vecx);
}

mat_GF2 buildEquivM(RoundFunction const & Tr, 
				    mat_GF2 const & invAprime,
				    vector<pair<mat_GF2,mat_GF2>> const & candidateBi){
//return an equivalent M
//candidateBi contains one candidate for each Bi as {B0,b0}, ..., {B31,b31}
	
	//Build M
	mat_GF2 M; M.SetDims(256,0);
	for(unsigned int i = 0; i < 32; i++){

		auto const & Bi = candidateBi[i].first;
		mat_GF2 invBi(inv(Bi));
		auto const & bi = candidateBi[i].second;
		mat_GF2 invbi(invBi*bi);

		//Start from (x0 0 .... 0)
		mat_GF2 x0 = random_mat_GF2(8,1);
		mat_GF2 cst = random_mat_GF2(8,1);
		mat_GF2 w0 = Bi*x0 + bi;
		mat_GF2 y0 = matGF2FromUint8(getSbox(uint8FromMatGF2(w0)));
		//Compute the image of inv(A'r)*x0 through the tables
		mat_GF2 z0 = zFromOneActiveByte(Tr, invAprime, i, x0, cst);


		//Now using 8 other values, get the 8 columns of Mi
		for(unsigned int v = 0; v < 8; v++){
			mat_GF2 y = y0 + matGF2FromUint8(1 << v);
			mat_GF2 w = matGF2FromUint8(getInvSbox(uint8FromMatGF2(y)));
			mat_GF2 x = invBi*w + invbi;

			mat_GF2 z = zFromOneActiveByte(Tr, invAprime, i, x, cst);

			ref_mat_augment(M, z0 + z);
		}
	}
	return M;
}