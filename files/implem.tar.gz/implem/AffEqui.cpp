#include "AffEqui.hpp"

using namespace std;
using namespace NTL;

Data::Data(const unsigned int n_in) :	n(n_in), m_sets(10), m_vecs(5, vector<uint8_t>(1<<n_in,0)) {
	DA().emplace(0);
	DB().emplace(0);
	NA().emplace(0);
	NB().emplace(0);

	unsigned int const pow2n = (1<<n_in);
	for(unsigned int x = 1; x < pow2n; x++){
		//UA,UB and UAinv are initialized to GF(2)^n\{0}
		UA().emplace(x);
		UB().emplace(x);
		UAinv().emplace(x);
	}
}


void Data::printState() const {
	cout << "DA : ";
	DA().apply([](unsigned x){
		cout << (unsigned int)x << " ";
	});
	cout << endl;
	cout << "UA : ";
	UA().apply([](unsigned x){
		cout << (unsigned int)x << " ";
	});
	cout << endl;
	cout << "UAinv : ";
	UAinv().apply([](unsigned x){
		cout << (unsigned int)x << " ";
	});
	cout << endl << endl;

}

void Data::makeGuessA(const uint8_t x, const uint8_t y){ //fonction bugguée, DA modifié dans la boucle
	//Guess A[x] = y and update the sets accordingly

	if(!NA().empty()){
		cout << "NA is not empty, no need to guess";
	}
	else{
		DA().apply([this,x,y](unsigned xa){
			uint8_t xapx = xa^x;
			uint8_t Axapy = A(xa)^y;

			A(xapx) = Axapy;	//A[DA + x] = A[DA] + A[x] = A[DA] + y
			Ainv(Axapy) = xapx;	//Ainv[A[DA]+y] = DA + x

			NA().emplace(xapx);	//NA = DA + x
			UA().erase(xapx);		//UA = UA\(DA+x)
			UAinv().erase(Axapy); //UAinv = UAinv\A(DA+x)
		});

		//Na = DA+x at this point
		DA() += NA();
	}
}

bool Data::compRs(vector<uint8_t> const & Rsmin){
	//return true if Rs is necessarily > Rsmin
	//false if Rs <= Rsmin or if it can't be decided (if Rs is not completly determined)

	unsigned int track = 0;
	unsigned int i = DRs().first();
	while (i != ~0u) {
		//at step i, for all j < i, Rs[j] is determined and Rs[j] == Rsmin[j]
		if(i != track){
			//then Rs[track] is not determined,
			//thus the step i and the previous step are not consecutive index
			//so we cant know if Rs is necessarily >= Rsmin
			return false;
		}
		if(Rs(i) < Rsmin[i]){
			//then we necessarily have Rs < Rsmin
			return false;
		}
		if(Rs(i) > Rsmin[i]){
			//then we necessarily have Rs > Rsmin
			return true;
		}
		track++;
		i = DRs().first_next(i);
	}
	//if we went through all the values of DRs without returning
	//then Rs == Rsmin
	return false;
}

bool Data::buildB(vector<uint8_t> const & S, vector<uint8_t> const & Sinv, vector<uint8_t> const & Rsmin){
	//NA is non empty, so we can build some news values for B from x = min(NA) and y = min(UB)
	//return false if it imply that the candidate representative is larger than Rsmin
	//		 true otherwise

	uint8_t x = NA().first();	//x = min(NA)
	uint8_t y = UB().first();	//y = min(UB)
	uint8_t SAx = S[A(x)];

	B(y) = SAx;		//B[y] = S[A[x]]
	Binv(SAx) = y;
	Rs(x) = y;
	DRs().emplace(x);

	Subset BDBy;
	DB().apply([this,&BDBy,y,SAx](unsigned yb){
		uint8_t const ybpy = yb^y;
		uint8_t const BybpSAx = B(yb)^SAx;

		B(ybpy) = BybpSAx;		//B[DB+y] = B[DB]+B[y] = B[DB] + S[A[x]]
		Binv(BybpSAx) = ybpy;	//Binv[B[DB]+B[y]] = DB + y

		UB().erase(ybpy);			//UB = UB\(DB+y)
		BDBy.emplace(BybpSAx);	//BDBy = B(DB+y)
	});

	Subset SANA;
	NA().apply([&SANA,&S,this](unsigned a){
		SANA.emplace(S[A(a)]);
	});

	(SANA & BDBy).apply([this,&S,&Sinv](unsigned i){
		auto const tmp = Ainv(Sinv[i]);
		auto const tmp2 = Binv(i);
		Rs(tmp) = tmp2;
		CB().emplace(tmp2);
		NA().erase(tmp);
		CA().emplace(tmp);
		DRs().emplace(tmp);
		DB().emplace(tmp2);
	});

	(BDBy - SANA).apply([this](unsigned i){
		auto const tmp = Binv(i);
		NB().emplace(tmp);
		DB().emplace(tmp);
	});


/*

	std::set<uint8_t> DBy, BDBy;
	for(auto const & yb : DB()){
		uint8_t ybpy = yb^y;
		uint8_t BybpSAx = B(yb)^SAx;

		B(ybpy) = BybpSAx;		//B[DB+y] = B[DB]+B[y] = B[DB] + S[A[x]]
		Binv(BybpSAx) = ybpy;	//Binv[B[DB]+B[y]] = DB + y

		DBy.emplace(ybpy);		//DBy = DB + y
		UB().erase(ybpy);			//UB = UB\(DB+y)
		BDBy.emplace(BybpSAx);	//BDBy = B(DB+y)
	}

	std::set<uint8_t> SANA;		//SANA = S(A(NA))
	for(auto const & xa : NA()){
		SANA.emplace(S[A(xa)]);
	}

	std::set<uint8_t> I;		//I = S(A(NA)) n B(DB+y)
	set_intersection(SANA.begin(),SANA.end(),
					 BDBy.begin(),BDBy.end(),
             		 inserter(I,I.begin()));

	std::set<uint8_t> AiSiI;	//AiSiI = Ainv(Sinv(I))
	for(auto const & xi : I){
		AiSiI.emplace(Ainv(Sinv[xi]));
		CB().emplace(Binv(xi));	//CB = CB u Binv(I)
	}

	for(auto const & yb : DBy){
		DB().emplace(yb);			//DB = DB u (DB+y)
	}

	auto SANA_end = SANA.end();
	for(auto const & yb : BDBy){
		if(SANA.find(yb) == SANA_end){
			//yb not in SANA
			NB().emplace(Binv(yb));//NB = NB u Binv( B(DB+y)\S(A(NA)) )
		}
	}

	for(auto const & xa : AiSiI){
		CA().emplace(xa); 		//CA = CA u Ainv(Sinv( I ))
		Rs(xa) = Binv(S[A(xa)]);//Rs[xa] = Binv(S(A(xa))), since xa is in AiSiI, Binv( S(A(xa)) ) can be computed
		DRs().emplace(xa);
		NA().erase(xa);			//NA = NA \ Ainv(Sinv( I ))
	}
	// if Rs > Rsmin, return false (the current candidate representative cant be smaller than Rsmin, which is the current smallest permutation)
	//compRs(Rsmin) return true if Rs > Rsmin
	*/
	return !compRs(Rsmin);
}

bool Data::buildA(vector<uint8_t> const & S, vector<uint8_t> const & Sinv, vector<uint8_t> const & Rsmin){
	//NB is non empty, so we can build some news values for A from x = min(UA) and y = min(NB)
	//return false if it imply that the candidate representative is larger than Rsmin
	//		 true otherwise

	uint8_t x = UA().first();	//x = min(UA)
	uint8_t y = NB().first();	//y = min(NB)
	uint8_t SiBy = Sinv[B(y)];

	A(x) = SiBy;				//A[x] = Sinv(B(y))
	Ainv(SiBy) = x;
	Rs(x) = y;
	DRs().emplace(x);

	Subset DAx, SADAx;
	DA().apply([this,&S,&DAx,&SADAx,x,SiBy](unsigned xa){
		uint8_t xapx = xa^x;
		uint8_t AxapSiBy = A(xa)^SiBy;

		A(xapx) = AxapSiBy; 	//A[DA+x] = A[DA]+A[x] = A[DA] + Sinv(B(y)) = AxapSiBy
		Ainv(AxapSiBy) = xapx;	//Ainv[A[DA]+A[x]] = DA+x

		DAx.emplace(xapx);		//DAx = DA+x
		UAinv().erase(AxapSiBy);	//UAinv = UAinv\(A(DA+x))
		SADAx.emplace(S[AxapSiBy]);//SADAx = S(A(Da+x))
	});

	UA() -= DAx; //UA = UA\(DA+x)

	Subset BNB;
	NB().apply([&BNB,this](unsigned yb){
		BNB.emplace(B(yb));		//BNB = B(NB)
	});

	Subset I = SADAx & BNB;		//I = S(A(Da+x)) n B(NB)

	Subset BiI;
	I.apply([this,&Sinv,&BiI](unsigned xi){
		BiI.emplace(Binv(xi));	//BiI = Binv(I)
		CA().emplace(Ainv(Sinv[xi]));//CA = CA u Ainv(Sinv(I))
	});

	DA() += DAx;

	(SADAx - BNB).apply([this,&Sinv](unsigned xa){
		NA().emplace(Ainv(Sinv[xa])); //NA = NA u Ainv(Sinv( S(A(DA+x)) \ B(NB) ))
	});

	CB() += BiI; //CB = CB u Binv(I)
	NB() -= BiI; //NB = NB \ Binv(I)

	BiI.apply([this,&Sinv](unsigned yb){
		uint8_t xa = Ainv(Sinv[B(yb)]);	//xa = Ainv(Sinv(B(yb))), since yb is in BiI, Ainv(Sinv(B(yb))) can be computed
		Rs(xa) = yb;
		DRs().emplace(xa);
	});

	// if Rs > Rsmin, return false (the current candidate representative cant be smaller than Rsmin, which is the current smallest candidate)
	//compRs(Rsmin) return true if Rs > Rsmin
	return !compRs(Rsmin);
}

bool Data::incrementalBuild(vector<uint8_t> const & S, vector<uint8_t> const & Sinv, vector<uint8_t> const & Rsmin){
	//build some values of A and B from NA and NB
	//return false if it implies that the current candidate representative is necessarily > Rsmin (smallest known candidate)
	//		 true otherwise

	while(!NA().empty()){
		bool isvalid = buildB(S,Sinv,Rsmin);
		if(!isvalid){
			//if the candidate representative is larger than Rsmin,
			//then no need to continue, this candidate can't be the representative
			return false;
		}
		while(NA().empty() && !NB().empty()){
			bool isvalid2 = buildA(S,Sinv,Rsmin);
			if(!isvalid2){
				//if the candidate representative is larger than Rsmin,
				//then no need to continue, this candidate can't be the representative
				return false;
			}
		}
	}
	//if we got here, then all the new values we built for A and B (and thus Rs) can still lead to a possible representative
	return true;
}


Data findRepr(vector<uint8_t> const & S, const unsigned int n){
	//find the representative of S, n-bit sbox

	//compute Sinv
	unsigned int S_size = S.size();
	vector<uint8_t> Sinv(S_size);
	for(unsigned int x = 0; x < S_size; x++){
		Sinv[S[x]] = x;
	}

	Data minRepr (n);
	list<Data> L (1,minRepr);
	if(S[0] == 0){
		//special case, we already have some information that Rs(0) = 0
		auto & initd = *(L.begin());
		initd.Rs(0) = 0;
		initd.DRs().emplace(0);
		initd.CA().emplace(0);
		initd.CB().emplace(0);
		initd.NA().erase(0);
		initd.NB().erase(0);
	}

	//initialize Rsmin to the "largest" permutation, which is [m, m-1, ..., 0], m = 2^n - 1 = S_size-1
	// vector<uint8_t> Rsmin(S_size, S_size); //Doesn't work, probably because of compRs
	for(unsigned int x = 0; x < S_size; x++){
		minRepr.Rs(x) = S_size-1-x;
	}

	while(!L.empty()) {
		auto & my_Data = L.front();
		bool canBeMinimal = my_Data.incrementalBuild(S,Sinv,minRepr.Rs());
		if(canBeMinimal){
			//if d.Rs is not necessarily > Rsmin (smallest known candidate for now)
			if(!my_Data.UA().empty()){
				//if UA or UB are not empty, then Rs is still not completly determined
				//so we need to make a guess for the smallest value is UA
				uint8_t const x = my_Data.UA().first(); //x = min(UA)
				auto const f = my_Data.UAinv().first();
				if (f != ~0u) {
					auto it_UAinv = my_Data.UAinv().first_next(f);
					while (it_UAinv != ~0u) {
						L.emplace_front(my_Data);
						L.front().makeGuessA(x,it_UAinv);
						it_UAinv = my_Data.UAinv().first_next(it_UAinv);
					}
					my_Data.makeGuessA(x,f);
				}
				else L.pop_front();
			}
			else {
				if (my_Data.Rs() < minRepr.Rs()) {
					//else, UA and UB are empty, which means that A,B and Rs are completly determined
					//so if Rs is smaller than Rsmin, Rs become the new smallest know candidate
					//since Rs and Rsmin are vector, and that all their values are determined
					//we can directly use the < operator for vector which do a lexicographical comparison
					//we test Rs <= Rsmin instead of < to include the case that the representative could actually be the "largest" permutation
					minRepr = move(my_Data);
				}
				L.pop_front();
			}
		}
		else L.pop_front();
	}

	return minRepr;
}

vector<mat_GF2> affineEquivalence(map<vector<uint8_t>, tuple<uint8_t, vector<uint8_t>, vector<uint8_t>>> & T1, vector<uint8_t> const & S2, const unsigned int n){
	//Return {a,A,b,B} such that B(S(Ax+a))+b = S2
	//T1 is to be computed before with equivClassAES() and contains the lin. equiv. classes of S(x+a) where S is the AES Sbox

	//T1[Rs] = (a,A,Binv) and T2[Rs] = (b,Ainv,B) where A,Ainv,B,Binv are linear maps represented as tables (vector)

	auto const T1_end = T1.end();
	unsigned int pow2n = (1 << n);

	uint8_t vala=0,valb=0;
	vector<uint8_t> A1, B1inv, A2inv, B2;

	for(unsigned int b = 0; b < pow2n; b++){
		//compute S2(x)+b
		vector<uint8_t> S2xb (S2);
		for(unsigned int x = 0; x < pow2n; x++){
			S2xb[x] ^= b;
		}
		//compute the representative of the lin. equiv. class of S2(x)+b
		Data repr = findRepr(S2xb,n);

		auto findReprT1 = T1.find(repr.Rs());
		if(findReprT1 != T1_end){
			tie(vala,A1,B1inv) = findReprT1->second;
			valb = b;
			A2inv = move(repr.Ainv());
			B2 = move(repr.B());
			break;
		}
	}

	mat_GF2 A,B,a,b;
	//build the matrix of A = A1.A2inv and B = B2.B1inv
	//since A1,A2inv are given in a tables form, we can build A directly from tables lookup on basis vector
	//the canonical basis (e0,...,e(n-1)) of GF(2)^n can be obtained with ei = (1 << i) in an uint representation
	//thus, the matrix A is built from the column vector (A[e0],...,A[e(n-1)]) with A[ei] = A1[A2inv[ei]]  = A1[A2inv[(1<<i)]]
	//same for B

	A.SetDims(n,n);
	B.SetDims(n,n);
	a.SetDims(n,1);
	b.SetDims(n,1);
	for(unsigned int j = 0; j < n; j++){
		//each column of A is A[ej]
		//each column of B is B[ej]
		uint8_t ej = (1<<j);
		uint8_t Aej = A1[A2inv[ej]];
		uint8_t Bej = B2[B1inv[ej]];

		for(unsigned int i = 0; i < n; i++){
			//A[i][j] is the i-th bit of Aej
			//B[i][j] is the i-th bit of Bej
			A[i][j] = Aej&1;
			Aej >>= 1;

			B[i][j] = Bej&1;
			Bej >>= 1;
		}

		//a[j] is the j-th bit of vala
		//b[j] is the j-th bit of valb
		a[j][0] = vala&1;
		vala >>= 1;
		b[j][0] = valb&1;
		valb >>= 1;
	}

	vector<mat_GF2> res;
	res.reserve(4);
	res.emplace_back(move(a));
	res.emplace_back(move(A));
	res.emplace_back(move(b));
	res.emplace_back(move(B));

	return res;
}

void testAffEqui(vector<mat_GF2> const & aAbB, vector<uint8_t> const & S1, vector<uint8_t> const & S2, unsigned int n){
	//test if B(S1(Ax+a))+b == S2

	unsigned int pow2n = (1<<n);
	mat_GF2 A(aAbB[1]);
	mat_GF2 B(aAbB[3]);
	mat_GF2 amat(aAbB[0]);
	mat_GF2 bmat(aAbB[2]);
	unsigned int vala=0, valb=0;

	for(unsigned int b = 0; b < n; b++){
		if(amat[b][0] == 1){
			vala ^= (1<<b);
		}
		if(bmat[b][0] == 1){
			valb ^= (1<<b);
		}
	}

	vector<uint8_t> tableA(pow2n);
	vector<uint8_t> tableB(pow2n);

	for(unsigned int x = 0; x < (pow2n); x++){
		mat_GF2 xmat;
		xmat.SetDims(n,1);
		for(unsigned int b = 0; b < n; b++){
			xmat[b][0] = (x>>b)&1;
		}
		mat_GF2 yA(A*xmat);
		mat_GF2 yB(B*xmat);

		unsigned int valyA = 0;
		unsigned int valyB = 0;
		for(unsigned int b = 0; b < n; b++){
			if(yA[b][0] == 1){
				valyA ^= (1<<b);
			}
			if(yB[b][0] == 1){
				valyB ^= (1<<b);
			}
		}
		tableA[x] = valyA;
		tableB[x] = valyB;
	}

	vector<uint8_t> tS2(pow2n);
	bool notequal = false;
	for(unsigned int x = 0; x < pow2n; x++){
		tS2[x] = tableB[S1[tableA[x]^vala]]^valb;
		if(tS2[x] != S2[x]){
			notequal = true;
		}
	}

	if(notequal){
		cout << "B(S1(Ax+a))+b IS NOT S2 " << endl;
	}
	else{
		cout << "B(S1(Ax+a))+b == S2" << endl;
	}

}

map<vector<uint8_t>, tuple<uint8_t, vector<uint8_t>, vector<uint8_t>>> equivClassAES(){
	//Compute the lin. equiv. classes of the AES Sbox
	auto const sboxAES = AES_SBOX();

	map<vector<uint8_t>, tuple<uint8_t, vector<uint8_t>, vector<uint8_t>>> linEqClass;
	vector<uint8_t> S1xa(256);
	for(unsigned int a = 0; a < 256; a++){
		//compute S1(x+a)
		for(unsigned int x = 0; x < 256; x++){
			S1xa[x] = sboxAES[x^a];
		}
		//compute the representative of the lin. equiv. class of S1(x+a)
		// cout << "compute the representative of the lin. equiv. class of S1(x+" << (unsigned int) a << ")..." << endl;
		Data repr = findRepr(S1xa,8);
		//store the corresponding (a,A,Binv) in linEqClass indexed by Rs

		linEqClass.emplace(move(repr.Rs()), make_tuple(a,move(repr.A()), move(repr.Binv())));
	}

	return linEqClass;
}

vector<vector<mat_GF2>> selfEquivAES(){
	//Return a vector of 2040 vector of the type {A1,A2,a2} such that A2(S(A1(x))+a2 = S where S is the AES sbox

	mat_GF2 As,as;
	tie(As,as) = AES_SBOX_Aff(); //S(x) = As(x^-1)+as
	mat_GF2 invAs = inv(As);

	vector<mat_GF2> mula = listMultGF2(); //mula[a] is the matrix corresponding to the multiplication by a in the Rinjdael Field
	mat_GF2 Q = GF256_squaringMatrix();   //Q is the matrix corresponding to the squaring operation in the Rinjdael Field

	vector<vector<mat_GF2>> listEquiv;
	for(unsigned int i = 0; i < 8; i++){
		mat_GF2 Qpowi = power(Q,i);
		mat_GF2 invQpowi = inv(Qpowi);
		for(unsigned int a = 1; a < 256; a++){
			mat_GF2 A1 = mula[a]*Qpowi;				//A1(x) = [a].Qi.x
			mat_GF2 A2 = As*invQpowi*mula[a]*invAs;	//A2(x) = A(invQi.[a].invA(x)) = As.invQi.[a].invAs.x + ( As.invQi.[a].invAs.as + as )
			mat_GF2 a2 = A2*as + as;
			listEquiv.emplace_back(vector<mat_GF2>({A1,A2,a2}));
		}
	}

	return listEquiv;

}
